/* DITA Studio renderer — v1.1 */
const P = window.api.path;

const S = {
  root: null,
  tree: [],
  file: null,
  dirty: false,
  mapDoc: null,
  mapProlog: '',
  depIndex: null,
  lastAutosaved: '',
  rootMap: null,        // absolute path of the key-space root map
  keyspace: null,       // { key: {href(abs or null), text} }
  ditaval: '',          // absolute path of selected .ditaval or ''
  filter: null,         // parsed DITAVAL rules
  previewTheme: 'light',
  fileCache: new Map(), // path -> {content, at}
  expandedDirs: new Set()
};

const $ = id => document.getElementById(id);
/* ---------------- Monaco editor + tabs ---------------- */

const monacoEd = monaco.editor.create($('editor'), {
  theme: 'vs-dark',
  automaticLayout: true,
  fontSize: 13,
  fontFamily: 'Cascadia Code, JetBrains Mono, Consolas, monospace',
  minimap: { enabled: true, maxColumn: 60 },
  tabSize: 2,
  insertSpaces: true,
  wordWrap: 'off',
  contextmenu: false,          // we draw our own DITA-aware menu
  folding: true,
  renderWhitespace: 'none',
  readOnly: true,
  stickyScroll: { enabled: true },
  scrollBeyondLastLine: false,
  unicodeHighlight: { ambiguousCharacters: false } // don't flag CJK punctuation
});

const TABS = { list: [], active: -1 };
const activeTab = () => (TABS.active >= 0 ? TABS.list[TABS.active] : null);
const activeModel = () => { const t = activeTab(); return t ? t.model : null; };

function langFor(p) {
  if (isDita(p)) return 'xml';
  if (isMd(p) || isMdx(p)) return 'markdown';
  const e = extOf(p);
  if (e === '.ditaval' || e === '.xml') return 'xml';
  if (e === '.css') return 'css';
  if (e === '.json') return 'json';
  return 'plaintext';
}

/* Compatibility adapter: keeps the rest of the app's editor API working on Monaco */
const editor = {
  get value() { const m = activeModel(); return m ? m.getValue() : ''; },
  set value(v) {
    const m = activeModel();
    if (!m) return;
    // full-range replace through the undo stack (Ctrl+Z friendly)
    m.pushEditOperations([], [{ range: m.getFullModelRange(), text: v }], () => null);
  },
  set disabled(v) { monacoEd.updateOptions({ readOnly: v }); $('editorEmpty').style.display = v && !activeTab() ? 'flex' : 'none'; },
  focus() { monacoEd.focus(); },
  select() { const m = activeModel(); if (m) monacoEd.setSelection(m.getFullModelRange()); }
};

function renderTabs() {
  const host = $('tabs');
  host.innerHTML = '';
  TABS.list.forEach((t, i) => {
    const d = document.createElement('div');
    d.className = 'tab' + (i === TABS.active ? ' active' : '') + (t.dirty ? ' dirty' : '');
    d.title = t.path;
    d.innerHTML = `<span class="tdot">●</span><span>${P.basename(t.path)}</span><button class="tclose" title="Close">×</button>`;
    d.onclick = () => activateTab(i);
    d.onauxclick = e => { if (e.button === 1) { e.preventDefault(); closeTab(i); } };
    d.querySelector('.tclose').onclick = e => { e.stopPropagation(); closeTab(i); };
    host.appendChild(d);
  });
}

function persistSession() {
  if (!S.root) return;
  try {
    const raw = JSON.parse(localStorage.getItem('ds:' + S.root) || '{}');
    raw.openTabs = TABS.list.map(t => t.path);
    raw.activeTab = TABS.active;
    raw.expandedDirs = Array.from(S.expandedDirs || []);
    raw.rootMap = S.rootMap; raw.ditaval = S.ditaval;
    localStorage.setItem('ds:' + S.root, JSON.stringify(raw));
  } catch (e) { /* ignore */ }
}

function activateTab(i) {
  const prev = activeTab();
  if (prev) prev.viewState = monacoEd.saveViewState();
  TABS.active = i;
  const t = activeTab();
  monacoEd.setModel(t.model);
  if (t.viewState) monacoEd.restoreViewState(t.viewState);
  monacoEd.updateOptions({ readOnly: false });
  $('editorEmpty').style.display = 'none';
  S.file = t.path;
  S.dirty = t.dirty;
  $('dirtyDot').hidden = !t.dirty;
  $('currentPath').textContent = t.path;
  enableFileButtons(true);
  $('btnRootMap').disabled = !isMap(t.path);
  renderTabs();
  highlightTreeActive();
  refreshMapModel();
  schedulePreview();
  scheduleValidation();
  updateStatusBar();
  updateBacklinks();
  persistSession();
  monacoEd.focus();
}

async function closeTab(i) {
  const t = TABS.list[i];
  if (t.dirty) {
    if (confirm(`"${P.basename(t.path)}" has unsaved changes.\nOK = save and close · Cancel = close without saving`)) {
      await window.api.writeFile(t.path, t.model.getValue());
      S.fileCache.delete(t.path);
    }
  }
  monaco.editor.setModelMarkers(t.model, 'ds', []);
  t.model.dispose();
  const wasActive = i === TABS.active;
  TABS.list.splice(i, 1);
  if (!TABS.list.length) {
    TABS.active = -1;
    closeFile();
    renderTabs();
    persistSession();
    return;
  }
  if (wasActive) {
    activateTab(Math.min(i, TABS.list.length - 1));
  } else {
    if (TABS.active > i) TABS.active--;
    renderTabs();
    persistSession();
  }
}

/* ---------------- small utils ---------------- */

function toast(msg) {
  let t = $('toast');
  if (!t) { t = document.createElement('div'); t.id = 'toast'; document.body.appendChild(t); }
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(t._h);
  t._h = setTimeout(() => t.classList.remove('show'), 2600);
}

function extOf(p) { return P.extname(p || '').toLowerCase(); }
function isMap(p) { return ['.ditamap', '.bookmap'].includes(extOf(p)); }
function isDita(p) { return ['.dita', '.xml'].includes(extOf(p)) || isMap(p); }
function isMd(p) { return ['.md', '.markdown'].includes(extOf(p)); }
function isMdx(p) { return extOf(p) === '.mdx'; }
function fileUrl(p) { return 'file:///' + p.replace(/\\/g, '/').replace(/^\//, ''); }
function escHtml(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }

const _existsCache = new Map();
async function existsCached(p) {
  const hit = _existsCache.get(p);
  if (hit && Date.now() - hit.at < 10000) return hit.v;
  const v = await window.api.exists(p);
  _existsCache.set(p, { v, at: Date.now() });
  return v;
}

async function readCached(p) {
  const hit = S.fileCache.get(p);
  if (hit && Date.now() - hit.at < 15000) return hit.content;
  const c = await window.api.readFile(p);
  S.fileCache.set(p, { content: c, at: Date.now() });
  return c;
}

function setDirty(d) {
  S.dirty = d;
  $('dirtyDot').hidden = !d;
  const b = $('btnSaveQuick');
  if (b) b.textContent = d ? 'Save ●' : 'Save';
}

function enableFileButtons(on) {
  ['btnSave', 'btnSaveQuick', 'btnExportHTML', 'btnExportPDF', 'btnDeps', 'btnVersions', 'btnPublishOT', 'btnWebHelp'].forEach(id => $(id).disabled = !on);
}

/* per-project persisted settings */
function loadProjectPrefs() {
  try {
    const raw = localStorage.getItem('ds:' + S.root);
    const p = raw ? JSON.parse(raw) : {};
    S.rootMap = p.rootMap || null;
    S.ditaval = p.ditaval || '';
    S.expandedDirs = new Set(p.expandedDirs || []);
  } catch (e) { S.rootMap = null; S.ditaval = ''; S.expandedDirs = new Set(); }
}
function saveProjectPrefs() {
  if (!S.root) return;
  localStorage.setItem('ds:' + S.root, JSON.stringify({ rootMap: S.rootMap, ditaval: S.ditaval }));
}

/* ---------------- project tree ---------------- */

$('btnOpenFolder').onclick = async () => {
  const r = await window.api.openFolder();
  if (!r) return;
  await loadProject(r.root, r.tree);
};

async function loadProject(root, tree) {
  S.root = root;
  S.tree = tree;
  S.depIndex = null;
  S.keyspace = null;
  S.fileCache.clear();
  loadProjectPrefs();
  localStorage.setItem('ds:lastRoot', root);
  ['btnNewFile', 'btnNewFolder', 'btnRefresh'].forEach(id => $(id).disabled = false);
  renderTree();
  await refreshDitavalList();
  if (S.rootMap && await window.api.exists(S.rootMap)) await buildKeyspace();
  updateRootMapStatus();
  recordRecentProject(root);
  $('wNewFile').disabled = false;
  renderWelcome();
}

$('btnRefresh').onclick = refreshTree;
async function refreshTree() {
  if (!S.root) return;
  _existsCache.clear();
  const r = await window.api.refreshTree(S.root);
  S.tree = r.tree;
  renderTree();
  refreshDitavalList();
}

function iconFor(node) {
  if (node.dir) return ['▸', ''];
  const e = extOf(node.name);
  if (e === '.ditamap' || e === '.bookmap') return ['◈', 'map'];
  if (e === '.dita' || e === '.xml') return ['◧', 'dita'];
  if (e === '.md' || e === '.mdx' || e === '.markdown') return ['¶', 'md'];
  return ['·', ''];
}

function renderTree() {
  const host = $('fileTree');
  host.innerHTML = '';
  S.treeRows = new Map();
  const rootLabel = document.createElement('div');
  rootLabel.className = 'trow dim';
  rootLabel.textContent = S.root;
  host.appendChild(rootLabel);
  host.appendChild(buildNodes(S.tree));
}

/* cheap active-highlight refresh — no DOM rebuild, expansion state untouched */
function highlightTreeActive() {
  if (!S.treeRows) return;
  for (const [p, row] of S.treeRows) row.classList.toggle('active', S.file === p);
}

function buildNodes(nodes) {
  const frag = document.createDocumentFragment();
  for (const n of nodes) {
    const wrap = document.createElement('div');
    wrap.className = 'tnode';
    const row = document.createElement('div');
    row.className = 'trow';
    if (S.file === n.path) row.classList.add('active');
    const [glyph, cls] = iconFor(n);
    row.innerHTML = `<span class="ticon ${cls}">${glyph}</span><span class="tname">${n.name}</span>` +
      `<span class="tops"><button data-op="ren" title="Rename (updates inbound references)">r</button><button data-op="del" title="Delete">×</button></span>`;
    row.querySelector('[data-op=ren]').onclick = e => { e.stopPropagation(); renameNode(n); };
    row.querySelector('[data-op=del]').onclick = e => { e.stopPropagation(); deleteNode(n); };
    row.addEventListener('contextmenu', e => { e.preventDefault(); e.stopPropagation(); treeContextMenu(n, e.clientX, e.clientY); });
    if (!n.dir) {
      row.draggable = true;
      row.addEventListener('dragstart', e => {
        e.dataTransfer.setData('text/ds-path', n.path);
        e.dataTransfer.effectAllowed = 'copy';
      });
    }
    // drop targets: map files (add as included content) and folders (move file here)
    const isDropMap = !n.dir && isMap(n.path);
    if (isDropMap || n.dir) {
      row.addEventListener('dragover', e => {
        if (!hasFileDrag(e)) return;
        e.preventDefault();
        e.stopPropagation();
        row.classList.add(isDropMap ? 'drop-map' : 'drop-dir');
      });
      row.addEventListener('dragleave', () => row.classList.remove('drop-map', 'drop-dir'));
      row.addEventListener('drop', async e => {
        row.classList.remove('drop-map', 'drop-dir');
        if (!hasFileDrag(e)) return;
        e.preventDefault();
        e.stopPropagation();
        const src = e.dataTransfer.getData('text/ds-path');
        if (!src || src === n.path) return;
        if (isDropMap) {
          await addFileToMap(n.path, src);
        } else {
          const dest = P.join(n.path, P.basename(src));
          if (P.resolve(P.dirname(src)) === P.resolve(n.path)) return;
          if (await window.api.exists(dest)) { toast('A file with that name already exists there.'); return; }
          if (!confirm(`Move ${P.basename(src)} into ${n.name}/ ?`)) return;
          try {
            const count = await moveFileWithRefs(src, dest);
            toast(count ? `Moved; ${count} referencing file(s) updated.` : 'Moved.');
          } catch (err) { toast('Move failed: ' + err.message); }
        }
      });
    }
    wrap.appendChild(row);
    if (n.dir) {
      const kids = document.createElement('div');
      kids.className = 'tkids';
      kids.appendChild(buildNodes(n.children || []));
      const expanded = S.expandedDirs.has(n.path);
      kids.hidden = !expanded;
      row.querySelector('.ticon').textContent = expanded ? '▾' : '▸';
      wrap.appendChild(kids);
      row.onclick = () => {
        kids.hidden = !kids.hidden;
        if (kids.hidden) S.expandedDirs.delete(n.path); else S.expandedDirs.add(n.path);
        row.querySelector('.ticon').textContent = kids.hidden ? '▸' : '▾';
      };
    } else {
      row.onclick = () => openFile(n.path);
    }
    frag.appendChild(wrap);
  }
  return frag;
}

/* shared: move/rename a file and offer to rewrite inbound references */
async function moveFileWithRefs(oldPath, newPath) {
  let updates = [];
  const oldAbs = P.resolve(oldPath);
  const files = await getProjectFiles(true); // moves need a fresh view
  const idx = window.DEPS.build(files, P);
  const inbound = idx.reverse.get(oldAbs) || [];
  const byFile = new Set(inbound.map(r => r.from));
  for (const from of byFile) {
    const f = files.find(x => P.resolve(x.path) === from);
    if (!f) continue;
    const oldRel = P.relative(P.dirname(f.path), oldPath).split(P.sep).join('/');
    const newRel = P.relative(P.dirname(f.path), newPath).split(P.sep).join('/');
    const re = new RegExp(oldRel.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g');
    const next = f.content.replace(re, newRel);
    if (next !== f.content) updates.push({ path: f.path, content: next });
  }
  if (updates.length &&
      !confirm(`${updates.length} file(s) reference "${P.basename(oldPath)}". Rewrite their links to the new location as well?`)) {
    updates = [];
  }
  await window.api.renamePath(oldPath, newPath);
  for (const u of updates) await window.api.writeFile(u.path, u.content);
  const tb = TABS.list.find(t => P.resolve(t.path) === P.resolve(oldPath));
  if (tb) tb.path = newPath;
  if (S.file === oldPath) { S.file = newPath; $('currentPath').textContent = newPath; }
  renderTabs();
  persistSession();
  S.depIndex = null;
  S.fileCache.clear();
  await refreshTree();
  return updates.length;
}

async function renameNode(n) {
  const name = prompt('New name for ' + n.name, n.name);
  if (!name || name === n.name) return;
  const to = P.join(P.dirname(n.path), name);
  try {
    if (n.dir) {
      await window.api.renamePath(n.path, to);
      await refreshTree();
      toast('Folder renamed. Note: references into it are not rewritten — check Dependencies.');
    } else {
      const count = await moveFileWithRefs(n.path, to);
      toast(count ? `Renamed; ${count} referencing file(s) updated.` : 'Renamed.');
    }
  } catch (e) { toast('Rename failed: ' + e.message); }
}

async function deleteNode(n) {
  if (!confirm(`Delete ${n.dir ? 'folder' : 'file'} "${n.name}"? This cannot be undone.`)) return;
  try {
    await window.api.deletePath(n.path);
    const ti = TABS.list.findIndex(t => P.resolve(t.path) === P.resolve(n.path));
    if (ti >= 0) {
      TABS.list[ti].dirty = false; // it's gone from disk; don't offer to save
      await closeTab(ti);
    }
    S.depIndex = null;
    await refreshTree();
  } catch (e) { toast('Delete failed: ' + e.message); }
}

$('btnNewFolder').onclick = async () => {
  const name = prompt('New folder name (created under project root):', 'topics');
  if (!name) return;
  await window.api.createFolder(P.join(S.root, name));
  refreshTree();
};

/* ---------------- new file ---------------- */

const dlgNew = $('dlgNew');

function refreshTemplateKinds() {
  const sel = $('newKind');
  sel.innerHTML = '';
  for (const k of window.TEMPLATES.kinds) {
    const o = document.createElement('option');
    o.value = k.key;
    o.textContent = `${k.label}  (${k.ext})`;
    sel.appendChild(o);
  }
  // project templates: any file under a top-level ".templates" or "templates" folder
  const projTemplates = [];
  (function walk(nodes, inTpl) {
    for (const n of nodes) {
      if (n.dir) walk(n.children || [], inTpl || ['.templates', 'templates'].includes(n.name));
      else if (inTpl && ['.dita', '.ditamap', '.bookmap', '.md', '.mdx'].includes(extOf(n.name))) {
        projTemplates.push(n);
      }
    }
  })(S.tree || [], false);
  if (projTemplates.length) {
    const grp = document.createElement('optgroup');
    grp.label = 'Project templates';
    for (const t of projTemplates) {
      const o = document.createElement('option');
      o.value = 'proj:' + t.path;
      o.textContent = t.name;
      grp.appendChild(o);
    }
    sel.appendChild(grp);
  }
}

function openNewFileDialog(dir) {
  refreshTemplateKinds();
  $('newDir').value = dir || (S.file ? P.dirname(S.file) : S.root) || '';
  $('newName').value = '';
  $('newTitle').value = '';
  const canAddToMap = !!(S.file && isMap(S.file) && S.mapDoc);
  $('newAddToMap').disabled = !canAddToMap && !S.pendingInsert;
  $('newAddToMap').checked = !!S.pendingInsert;
  dlgNew.showModal();
  $('newName').focus();
}

$('btnNewFile').onclick = () => { S.pendingInsert = null; openNewFileDialog(); };
$('btnNewBrowse').onclick = async () => {
  const d = await window.api.pickFolder('Choose where to save the new file');
  if (d) $('newDir').value = d;
};
dlgNew.addEventListener('close', () => { if (dlgNew.returnValue !== 'ok') S.pendingInsert = null; });

$('frmNew').addEventListener('submit', async e => {
  if (e.submitter && e.submitter.value === 'cancel') return;
  const kindKey = $('newKind').value;
  const name = $('newName').value.trim();
  const title = $('newTitle').value.trim() || name;
  const dir = $('newDir').value.trim() || S.root;
  const id = name.replace(/[^A-Za-z0-9_-]/g, '_');
  try {
    let file, content;
    if (kindKey.startsWith('proj:')) {
      const src = kindKey.slice(5);
      file = P.join(dir, name + extOf(src));
      content = (await window.api.readFile(src))
        .replace(/\$\{TITLE\}/g, title)
        .replace(/\$\{ID\}/g, id);
    } else {
      const kind = window.TEMPLATES.kinds.find(k => k.key === kindKey);
      file = P.join(dir, name + kind.ext);
      content = window.TEMPLATES.make(kindKey, id, title);
    }
    await window.api.createFile(file, content);

    // optional: wire the new file into the open map
    const pending = S.pendingInsert;
    S.pendingInsert = null;
    if (S.file && isMap(S.file) && S.mapDoc && (pending || $('newAddToMap').checked)) {
      const parent = pending || S.mapDoc.documentElement;
      parent.appendChild(makeRefEl(S.mapDoc, S.file, file, parent.tagName));
      writeMapToEditor();
      await save();               // keep the map consistent on disk before switching away
      toast('Reference added to ' + P.basename(S.file));
    }

    await refreshTree();
    openFile(file);
    toast('Created ' + P.basename(file));
  } catch (err) {
    e.preventDefault();
    toast(err.message);
  }
});

/* ---------------- open / save / close ---------------- */

const IMG_EXT = ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg', '.bmp', '.ico'];
const AV_EXT = ['.mp4', '.webm', '.ogv', '.mov', '.m4v', '.mp3', '.wav', '.m4a', '.oga', '.ogg', '.flac', '.aac'];

function previewBinary(p) {
  S.binaryPreviewHold = true;
  setTimeout(() => { S.binaryPreviewHold = false; }, 600); // outlive the debounce, then normal previews resume on next edit
  const url = fileUrl(p);
  const e = extOf(p);
  let inner;
  if (IMG_EXT.includes(e)) {
    inner = `<img src="${url}" style="max-width:100%;box-shadow:0 4px 24px rgba(0,0,0,.15);border-radius:6px">`;
  } else if (/^\.(mp4|webm|ogv|mov|m4v)$/.test(e)) {
    inner = `<video controls autoplay muted style="max-width:100%;border-radius:6px" src="${url}"></video>`;
  } else {
    inner = `<audio controls src="${url}"></audio>`;
  }
  $('previewFrame').srcdoc = `<!DOCTYPE html><html><body style="margin:0;display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100vh;background:#20252c;font-family:Segoe UI,sans-serif">
    ${inner}<div style="color:#8b96a3;font-size:12px;margin-top:12px">${escHtml(P.basename(p))}</div></body></html>`;
  setRightMode('preview');
}

async function openFile(p) {
  const be = extOf(p);
  if (IMG_EXT.includes(be) || AV_EXT.includes(be)) { previewBinary(p); return; }
  try {
    const abs = P.resolve(p);
    const existing = TABS.list.findIndex(t => P.resolve(t.path) === abs);
    if (existing >= 0) {
      activateTab(existing);
      if (isMap(p) && $('previewPane').hidden === false) { /* keep pane */ }
      return;
    }
    const content = await window.api.readFile(p);
    const model = monaco.editor.createModel(content, langFor(p));
    const tab = { path: p, model, dirty: false, savedVid: model.getAlternativeVersionId(), viewState: null, lastAutosaved: content };
    TABS.list.push(tab);
    activateTab(TABS.list.length - 1);
    if (isMap(p)) setRightMode('map'); else setRightMode('preview');
  } catch (e) { toast('Open failed: ' + e.message); }
}

function closeFile() {
  S.file = null;
  S.mapDoc = null;
  monacoEd.setModel(null);
  monacoEd.updateOptions({ readOnly: true });
  $('editorEmpty').style.display = 'flex';
  setDirty(false);
  $('currentPath').textContent = 'No file open';
  enableFileButtons(false);
  $('btnRootMap').disabled = true;
  updateStatusBar();
}

async function save() {
  const t = activeTab();
  if (!t) return;
  await window.api.writeFile(t.path, t.model.getValue());
  S.fileCache.delete(t.path);
  S._pf = null;
  t.savedVid = t.model.getAlternativeVersionId();
  t.dirty = false;
  setDirty(false);
  renderTabs();
  toast('Saved ' + P.basename(t.path));
  if (S.rootMap && P.resolve(t.path) === P.resolve(S.rootMap)) buildKeyspace();
}
$('btnSave').onclick = save;
document.addEventListener('keydown', e => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); save(); }
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'w') { e.preventDefault(); if (TABS.active >= 0) closeTab(TABS.active); }
});

/* single change pipeline: dirty tracking, live model refresh, preview, validation */
monacoEd.onDidChangeModelContent(() => {
  const t = activeTab();
  if (!t) return;
  t.dirty = t.model.getAlternativeVersionId() !== t.savedVid;
  setDirty(t.dirty);
  renderTabs();
  maybeAutoCloseTag();
  refreshMapModel();
  schedulePreview();
  scheduleValidation();
  if (!$('outlinePane').hidden) renderOutline();
});

/* ---------------- editor smarts (Monaco handles Tab/Enter/indent natively) ---------------- */

/* auto-close XML tags: after typing '>', insert the matching closing tag */
let autoClosing = false;
function maybeAutoCloseTag() {
  if (autoClosing || !SETTINGS.autoCloseTags || !S.file || !isDita(S.file)) return;
  const m = activeModel();
  const pos = monacoEd.getPosition();
  if (!m || !pos) return;
  const line = m.getLineContent(pos.lineNumber);
  const before = line.slice(0, pos.column - 1);
  if (!before.endsWith('>') || before.endsWith('/>') || before.endsWith('->')) return;
  const tm = before.match(/<([A-Za-z][\w.-]*)((?:"[^"]*"|[^<>"])*)>$/);
  if (!tm) return;
  const after = line.slice(pos.column - 1);
  if (after.startsWith('</' + tm[1])) return; // already closed
  autoClosing = true;
  m.pushEditOperations([], [{
    range: new monaco.Range(pos.lineNumber, pos.column, pos.lineNumber, pos.column),
    text: `</${tm[1]}>`
  }], () => null);
  monacoEd.setPosition(pos); // caret stays between the tags
  autoClosing = false;
}

function insertAtCaret(text) {
  const sel = monacoEd.getSelection();
  if (!sel) return;
  monacoEd.executeEdits('ds-insert', [{ range: sel, text, forceMoveMarkers: true }]);
  monacoEd.focus();
}

function jumpTo(index) {
  const m = activeModel();
  if (!m || index < 0) return;
  const pos = m.getPositionAt(Math.min(index, m.getValueLength()));
  monacoEd.setPosition(pos);
  monacoEd.revealPositionInCenter(pos);
  monacoEd.focus();
}

/* ---------------- right pane modes ---------------- */

function setRightMode(mode) {
  document.querySelectorAll('.rt').forEach(b => b.classList.toggle('active', b.dataset.mode === mode));
  for (const m of ['preview', 'map', 'deps', 'problems', 'outline', 'search', 'ai']) {
    $(m + 'Pane').hidden = m !== mode;
  }
  $('rightTitle').textContent = mode.toUpperCase();
  if (mode === 'preview') schedulePreview();
  if (mode === 'map') renderMapTree();
  if (mode === 'deps') renderDeps();
  if (mode === 'problems') runValidation();
  if (mode === 'outline') renderOutline();
  if (mode === 'search') $('searchInput').focus();
  if (mode === 'assist') initAiPane();
  if (mode === 'ai') initAiPane();
}
document.querySelectorAll('.rt').forEach(b => b.onclick = () => setRightMode(b.dataset.mode));

/* ---------------- key space (root map) ---------------- */

$('btnRootMap').onclick = async () => {
  if (!S.file || !isMap(S.file)) return;
  S.rootMap = P.resolve(S.file);
  saveProjectPrefs();
  await buildKeyspace();
  updateRootMapStatus();
  toast('Root map set: ' + P.basename(S.rootMap));
  schedulePreview();
  scheduleValidation();
};

function updateRootMapStatus() {
  $('rootMapStatus').textContent = S.rootMap
    ? `root map: ${P.basename(S.rootMap)} (${S.keyspace ? Object.keys(S.keyspace).length : 0} keys)`
    : 'no root map';
}

async function buildKeyspace(mapPath, depth, ks, visited) {
  const isTop = !mapPath;
  if (isTop) {
    mapPath = S.rootMap;
    depth = 0; ks = {}; visited = new Set();
    if (!mapPath) { S.keyspace = null; return; }
  }
  const abs = P.resolve(mapPath);
  if (visited.has(abs) || depth > 4) return;
  visited.add(abs);
  let doc;
  try {
    const txt = (S.file && P.resolve(S.file) === abs) ? editor.value : await readCached(abs);
    doc = new DOMParser().parseFromString(txt, 'application/xml');
    if (doc.querySelector('parsererror')) doc = null;
  } catch (e) { doc = null; }
  if (doc) {
    const dir = P.dirname(abs);
    for (const el of doc.querySelectorAll('[keys]')) {
      for (const key of el.getAttribute('keys').split(/\s+/)) {
        if (!key || ks[key]) continue; // first definition wins (DITA key precedence)
        const href = el.getAttribute('href');
        const navEl = el.querySelector(':scope > topicmeta > navtitle, :scope > topicmeta > keywords > keyword, :scope > topicmeta > linktext');
        ks[key] = {
          href: href && !/^([a-z]+:)?\/\//i.test(href) ? P.resolve(P.join(dir, href.split('#')[0])) : (href || null),
          hrefRaw: href || null,
          text: (navEl && navEl.textContent.trim()) || el.getAttribute('navtitle') || null
        };
      }
    }
    for (const el of doc.querySelectorAll('mapref[href], topicref[format="ditamap"][href]')) {
      const h = el.getAttribute('href');
      if (h && !/^([a-z]+:)?\/\//i.test(h)) {
        await buildKeyspace(P.join(P.dirname(abs), h.split('#')[0]), depth + 1, ks, visited);
      }
    }
  }
  if (isTop) { S.keyspace = ks; updateRootMapStatus(); }
}

/* key space entries with hrefs relative to a consuming file's dir */
function keyspaceFor(fileDir) {
  if (!S.keyspace) return null;
  const out = {};
  for (const [k, v] of Object.entries(S.keyspace)) {
    let href = v.hrefRaw;
    if (v.href && !/^([a-z]+:)?\/\//i.test(v.href || '')) {
      try { href = P.relative(fileDir, v.href).split(P.sep).join('/'); } catch (e) { /* keep raw */ }
    }
    out[k] = { href, text: v.text };
  }
  return out;
}

/* ---------------- DITAVAL ---------------- */

async function refreshDitavalList() {
  const sel = $('ditavalSel');
  const files = [];
  (function walk(nodes) {
    for (const n of nodes) {
      if (n.dir) walk(n.children || []);
      else if (extOf(n.name) === '.ditaval') files.push(n.path);
    }
  })(S.tree);
  sel.innerHTML = '<option value="">No DITAVAL filter</option>';
  for (const f of files) {
    const o = document.createElement('option');
    o.value = f;
    o.textContent = 'DITAVAL: ' + P.relative(S.root, f);
    sel.appendChild(o);
  }
  sel.disabled = false;
  if (S.ditaval && files.includes(S.ditaval)) sel.value = S.ditaval; else { S.ditaval = ''; }
  await loadDitaval();
}

$('ditavalSel').onchange = async () => {
  S.ditaval = $('ditavalSel').value;
  saveProjectPrefs();
  await loadDitaval();
  schedulePreview();
};

async function loadDitaval() {
  S.filter = null;
  $('ditavalSel').classList.toggle('filter-on', !!S.ditaval);
  const chip = $('stDitaval');
  chip.hidden = !S.ditaval;
  if (S.ditaval) chip.textContent = '⧩ ' + P.basename(S.ditaval);
  if (!S.ditaval) return;
  try {
    const txt = await readCached(S.ditaval);
    const doc = new DOMParser().parseFromString(txt, 'application/xml');
    if (doc.querySelector('parsererror')) return;
    S.filter = Array.from(doc.querySelectorAll('prop')).map(p => ({
      att: p.getAttribute('att') || null,
      val: p.getAttribute('val') || null,
      action: (p.getAttribute('action') || '').toLowerCase()
    })).filter(r => ['exclude', 'include', 'flag'].includes(r.action));
  } catch (e) { /* ignore */ }
}

/* ---------------- conref resolution ---------------- */

async function resolveConrefs(doc, filePath, depth) {
  if (depth > 3) return;
  const els = Array.from(doc.querySelectorAll('[conref], [conkeyref]'));
  for (const el of els) {
    let target = el.getAttribute('conref');
    let baseFile = filePath;
    if (!target) {
      const ckr = el.getAttribute('conkeyref'); // key/elementId
      const [key, elemId] = ckr.split('/');
      const k = S.keyspace && S.keyspace[key];
      if (!k || !k.href) { markUnresolved(el, doc, 'conkeyref ' + ckr); continue; }
      baseFile = filePath; // href in keyspace is absolute
      target = k.href + (elemId ? '#' + '*/' + elemId : '');
      el._absTarget = k.href;
    }
    try {
      const [pathPart, frag] = target.split('#');
      const abs = el._absTarget || (pathPart
        ? P.resolve(P.join(P.dirname(baseFile), pathPart))
        : P.resolve(filePath));
      const txt = (S.file && P.resolve(S.file) === abs) ? editor.value : await readCached(abs);
      const tdoc = new DOMParser().parseFromString(txt, 'application/xml');
      if (tdoc.querySelector('parsererror')) { markUnresolved(el, doc, target); continue; }
      let found = null;
      if (frag) {
        const parts = frag.split('/');
        const elemId = parts.length > 1 ? parts[1] : parts[0];
        found = tdoc.querySelector(`[id="${CSS.escape(elemId)}"]`);
      } else {
        found = tdoc.documentElement;
      }
      if (!found) { markUnresolved(el, doc, target); continue; }
      await resolveConrefs(tdoc, abs, depth + 1);
      const imported = doc.importNode(found, true);
      imported.removeAttribute('conref');
      imported.removeAttribute('conkeyref');
      el.parentNode.replaceChild(imported, el);
    } catch (e) {
      markUnresolved(el, doc, target);
    }
  }
}

function markUnresolved(el, doc, ref) {
  const ph = doc.createElement('ph');
  ph.setAttribute('outputclass', 'unresolved');
  ph.textContent = `[unresolved conref: ${ref}]`;
  el.parentNode.replaceChild(ph, el);
}

/* ---------------- preview / publish ---------------- */

const THEME = {
  light: { bg: '#ffffff', fg: '#1f2933', sub: '#52606d', code: '#f2f4f7', line: '#e1e5ea', link: '#1a6baa' },
  dark: { bg: '#181c22', fg: '#d7dde4', sub: '#9aa5b1', code: '#232b34', line: '#2a323c', link: '#6cb2e0' }
};

function publishCss(themeName) {
  const t = THEME[themeName] || THEME.light;
  return `
  body{font-family:"Segoe UI",system-ui,sans-serif;background:${t.bg};color:${t.fg};margin:0;padding:28px 34px;line-height:1.6;font-size:15px}
  h1{font-size:1.7em;border-bottom:2px solid #e0a458;padding-bottom:.25em}
  h2{font-size:1.3em;margin-top:1.6em}
  h3{font-size:1.1em}
  .shortdesc{color:${t.sub};font-size:1.02em}
  pre,.d-code{background:${t.code};border:1px solid ${t.line};border-radius:5px;padding:10px 12px;overflow:auto;font-family:Consolas,monospace;font-size:.92em}
  code,kbd,samp{background:${t.code};border-radius:3px;padding:1px 4px;font-family:Consolas,monospace;font-size:.92em}
  .d-note{border-left:4px solid #7fb3d5;background:${t.code};padding:8px 12px;margin:12px 0;border-radius:0 4px 4px 0}
  .d-note-warning,.d-note-caution,.d-note-danger{border-left-color:#d97b6c}
  .d-note-important,.d-note-attention{border-left-color:#e0a458}
  .d-note-label{font-weight:600}
  .d-block{margin:14px 0}
  .d-label{font-weight:600;font-size:.82em;letter-spacing:.08em;text-transform:uppercase;color:#b07a24;margin-bottom:2px}
  .d-cmd{font-weight:600}
  .d-steps>li{margin:8px 0}
  .d-stepinfo{color:${t.sub};margin:3px 0 3px 2px;font-size:.95em}
  table.d-table{border-collapse:collapse;margin:12px 0;width:100%}
  .d-table th,.d-table td{border:1px solid ${t.line};padding:6px 10px;text-align:left;vertical-align:top}
  .d-table th{background:${t.code}}
  figure.d-fig{margin:14px 0;text-align:center}
  figcaption{color:${t.sub};font-size:.9em;margin-top:4px}
  img{max-width:100%}
  .d-ui{background:${t.code};border:1px solid ${t.line};border-radius:3px;padding:0 5px;font-weight:600;font-size:.92em}
  a{color:${t.link}}
  blockquote{border-left:3px solid ${t.line};margin:10px 0;padding:2px 14px;color:${t.sub}}
  .mdx-comp{border:1px dashed #b9a06b;border-radius:5px;padding:8px 12px;margin:10px 0}
  .mdx-comp::before{content:"<" attr(data-name) ">";display:block;font-family:Consolas,monospace;font-size:.78em;color:#b07a24;margin-bottom:4px}
  .pub-error{color:#c0564a;border:1px solid #d97b6c;padding:10px 14px;border-radius:5px;font-family:Consolas,monospace;white-space:pre-wrap}
  .d-unresolved,[outputclass=unresolved]{color:#b06e2a;border-bottom:1px dotted #b06e2a}
  hr.topic-sep{border:0;border-top:1px solid ${t.line};margin:30px 0}
  .doc-contents{border:1px solid ${t.line};border-radius:8px;background:${t.code};padding:12px 18px;margin:18px 0}
  .doc-contents b{font-size:.82em;letter-spacing:.1em;text-transform:uppercase;color:${t.sub}}
  .doc-contents ol{margin:8px 0 2px;padding-left:22px}
  .doc-contents li{margin:3px 0}
  video,audio{max-width:100%;border-radius:6px;margin:10px 0}
  .d-embed{position:relative;aspect-ratio:16/9;margin:14px 0}
  .d-embed iframe{position:absolute;inset:0;width:100%;height:100%;border:0;border-radius:8px}
` + (STYLE_PACKS[SETTINGS.stylePack] || '') + '\n' + (S.customCssText || '');
}

$('btnPreviewTheme').onclick = () => {
  S.previewTheme = S.previewTheme === 'light' ? 'dark' : 'light';
  $('btnPreviewTheme').textContent = S.previewTheme === 'light' ? '☾' : '☀';
  schedulePreview();
};

function mdxToMarkdown(src) {
  let s = src;
  s = s.replace(/^---\r?\n[\s\S]*?\r?\n---\r?\n/, '');
  s = s.replace(/^\s*import\s+[^\n]+\n/gm, '');
  s = s.replace(/^\s*export\s+[^\n]+\n/gm, '');
  s = s.replace(/<([A-Z][A-Za-z0-9]*)([^>]*?)\/>/g, '<div class="mdx-comp" data-name="$1"></div>');
  s = s.replace(/<([A-Z][A-Za-z0-9]*)([^>]*)>/g, '<div class="mdx-comp" data-name="$1">');
  s = s.replace(/<\/[A-Z][A-Za-z0-9]*>/g, '</div>');
  s = s.replace(/\{([^{}\n]+)\}/g, '<code>{$1}</code>');
  return s;
}

function mdToHtml(src) {
  const body = src.replace(/^---\r?\n[\s\S]*?\r?\n---\r?\n/, '');
  return window.api.renderMarkdown(body);
}

/* async: resolves conrefs/keyrefs + applies DITAVAL for DITA content */
async function buildBodyHtml(path, content) {
  if (isMd(path)) return mdToHtml(content);
  if (isMdx(path)) return window.api.renderMarkdown(mdxToMarkdown(content));
  if (isDita(path) && !isMap(path)) {
    const doc = new DOMParser().parseFromString(content, 'application/xml');
    const err = doc.querySelector('parsererror');
    if (err) return `<div class="pub-error">XML parse error:\n${escHtml(err.textContent.trim())}</div>`;
    await resolveConrefs(doc, P.resolve(path), 0);
    const r = window.DITA.renderDoc(doc, {
      keyspace: keyspaceFor(P.dirname(path)),
      filter: S.filter
    });
    return r.html;
  }
  if (isMap(path)) return null;
  return `<pre>${escHtml(content)}</pre>`;
}

function publishDoc(title, bodyHtml, baseDir, theme) {
  const base = baseDir ? `<base href="${fileUrl(baseDir)}/">` : '';
  return `<!DOCTYPE html><html><head><meta charset="utf-8">${base}<title>${escHtml(title)}</title><style>${publishCss(theme || 'light')}</style></head><body>${bodyHtml}</body></html>`;
}

async function assembleMap(mapPath, content) {
  const doc = new DOMParser().parseFromString(content, 'application/xml');
  if (doc.querySelector('parsererror')) {
    return { title: P.basename(mapPath), body: `<div class="pub-error">Map XML parse error.</div>` };
  }
  const titleEl = doc.querySelector('booktitle > mainbooktitle') || doc.querySelector('map > title, bookmap > title, title');
  const title = titleEl ? titleEl.textContent.trim() : P.basename(mapPath);
  const hrefs = [];
  (function walk(el) {
    for (const ch of el.children) {
      const h = ch.getAttribute && ch.getAttribute('href');
      if (h && !/^([a-z]+:)?\/\//i.test(h)) {
        const clean = h.split('#')[0];
        const e = P.extname(clean).toLowerCase();
        if (['.dita', '.xml', '.md', '.mdx', '.markdown'].includes(e)) {
          hrefs.push(P.resolve(P.join(P.dirname(mapPath), clean)));
        }
      }
      walk(ch);
    }
  })(doc.documentElement);

  let body = `<h1>${escHtml(title)}</h1>`;
  if (!hrefs.length) body += `<p><em>No local topic references found in this map.</em></p>`;
  if (hrefs.length > 1) {
    const entries = [];
    for (let i = 0; i < hrefs.length; i++) {
      let t;
      try { t = await whTitleOf(hrefs[i]); } catch (e) { t = P.basename(hrefs[i]); }
      entries.push(`<li><a href="#topic-${i}">${escHtml(t)}</a></li>`);
    }
    body += `<nav class="doc-contents"><b>Contents</b><ol>${entries.join('')}</ol></nav>`;
  }
  for (let i = 0; i < hrefs.length; i++) {
    const f = hrefs[i];
    body += `<hr class="topic-sep"><div id="topic-${i}">`;
    try {
      const c = await readCached(f);
      body += (await buildBodyHtml(f, c)) || '';
    } catch (e) {
      body += `<div class="pub-error">Missing topic: ${escHtml(f)}</div>`;
    }
    body += '</div>';
  }
  return { title, body };
}

let previewTimer = null;
function schedulePreview() {
  clearTimeout(previewTimer);
  const delay = S.file && isMap(S.file) ? 700 : 300; // whole-map assembly costs more
  previewTimer = setTimeout(renderPreview, delay);
}

async function renderPreview() {
  if (S.binaryPreviewHold) return; // a picture/media preview is on screen
  if (!S.file || $('previewPane').hidden) return;
  const dir = P.dirname(S.file);
  let html;
  if (isMap(S.file)) {
    const a = await assembleMap(S.file, editor.value);
    html = publishDoc(a.title, a.body, dir, S.previewTheme);
  } else {
    let body = (await buildBodyHtml(S.file, editor.value)) || '';
    if (isMdx(S.file)) {
      body = `<div class="d-note d-note-important"><span class="d-note-label">MDX preview:</span> JSX components are shown as placeholders; Markdown content renders fully.</div>` + body;
    }
    html = publishDoc(P.basename(S.file), body, dir, S.previewTheme);
  }
  $('previewFrame').srcdoc = html;
}

/* ---------------- validation (Problems) ---------------- */

let validationTimer = null;
function scheduleValidation() {
  clearTimeout(validationTimer);
  validationTimer = setTimeout(runValidation, 700);
}

async function runValidation() {
  const out = $('problemsOut');
  const bar = $('problemsBar');
  const badge = $('problemCount');
  if (!S.file) {
    out.innerHTML = '<div class="dep-none">Open a file first.</div>';
    bar.innerHTML = '';
    badge.hidden = true;
    return;
  }
  const problems = [];
  const src = editor.value;
  const ext = extOf(S.file);

  const _projFiles = allProjectFiles();
  const nearestProjectFile = target => {
    const base = P.basename(target).toLowerCase();
    return _projFiles.find(f => P.basename(f).toLowerCase() === base) || null;
  };

  if (isDita(S.file) || ext === '.xml' || ext === '.ditaval') {
    const doc = new DOMParser().parseFromString(src, 'application/xml');
    const err = doc.querySelector('parsererror');
    if (err) {
      const msg = err.textContent.trim().split('\n')[0];
      const lm = err.textContent.match(/line[:\s]+(\d+)/i);
      let idx = 0;
      if (lm) {
        const lines = src.split('\n');
        idx = lines.slice(0, Math.max(0, +lm[1] - 1)).join('\n').length;
      }
      problems.push({ kind: 'XML', msg, at: idx });
      // raw-text diagnostics with fixes (bare &, tag mismatch location)
      for (const p of window.LINT.checkXmlRaw(src)) problems.push(p);
    } else {
      // structural DITA rules
      const root = doc.documentElement;
      if (['topic', 'concept', 'task', 'reference', 'troubleshooting', 'glossentry', 'map', 'bookmap'].includes(root.tagName) && !root.getAttribute('id')) {
        const suggested = P.basename(S.file, ext).replace(/[^A-Za-z0-9_-]/g, '_');
        problems.push({
          kind: 'DITA', msg: `Root <${root.tagName}> has no id`, at: src.indexOf('<' + root.tagName),
          fix: {
            label: `Add id="${suggested}"`,
            apply: t => t.replace(new RegExp('<' + root.tagName + '(?![\\w-])'), `<${root.tagName} id="${suggested}"`)
          }
        });
      }
      const seen = new Map();
      for (const el of doc.querySelectorAll('[id]')) {
        const id = el.getAttribute('id');
        if (seen.has(id)) {
          const at = src.indexOf(`id="${id}"`, seen.get(id) + 1);
          let n = 2;
          const allIds = new Set(Array.from(doc.querySelectorAll('[id]')).map(x => x.getAttribute('id')));
          while (allIds.has(`${id}-${n}`)) n++;
          problems.push({
            kind: 'ID', msg: `Duplicate id "${id}"`, at,
            fix: {
              label: `Rename this one to "${id}-${n}"`,
              apply: t => at >= 0 ? t.slice(0, at) + `id="${id}-${n}"` + t.slice(at + `id="${id}"`.length) : t
            }
          });
        } else {
          seen.set(id, src.indexOf(`id="${id}"`));
        }
      }
      // untyped notes
      if (/<note(?![\w-])(?![^>]*\btype=)/.test(src)) {
        const at = src.search(/<note(?![\w-])(?![^>]*\btype=)/);
        problems.push({ kind: 'DITA', msg: 'Note without a type attribute', at, fixId: 'dita-note-type' });
      }
      // images without alt
      for (const img of doc.querySelectorAll('image')) {
        if (!img.getAttribute('alt') && !img.querySelector('alt')) {
          const href = img.getAttribute('href') || '';
          problems.push({ kind: 'A11Y', msg: `Image without <alt>: ${href}`, at: href ? src.indexOf(href) : 0 });
        }
      }
      const dir = P.dirname(S.file);
      let checked = 0;
      for (const el of doc.querySelectorAll('[href], [conref], [data]')) {
        if (checked >= 120) break;
        for (const att of ['href', 'conref', 'data']) {
          const v = el.getAttribute(att);
          if (!v || /^([a-z]+:)?\/\//i.test(v) || /^(mailto|tel):/i.test(v)) continue;
          const clean = v.split('#')[0];
          if (!clean) continue;
          checked++;
          const abs = P.resolve(P.join(dir, clean));
          if (!(await existsCached(abs))) {
            const near = nearestProjectFile(clean);
            const prob = { kind: att.toUpperCase(), msg: `Target not found: ${v}`, at: src.indexOf(`${att}="${v}"`) };
            if (near) {
              const rel = P.relative(dir, near).split(P.sep).join('/');
              prob.msg += ` — did you mean ${rel}?`;
              prob.fix = {
                label: `Replace with ${rel}`,
                apply: t => t.replace(`${att}="${v}"`, `${att}="${rel}${v.includes('#') ? '#' + v.split('#')[1] : ''}"`)
              };
            }
            problems.push(prob);
          }
        }
      }
      for (const el of doc.querySelectorAll('[keyref], [conkeyref]')) {
        for (const att of ['keyref', 'conkeyref']) {
          const v = el.getAttribute(att);
          if (!v) continue;
          const key = v.split('/')[0];
          if (S.keyspace && !S.keyspace[key]) {
            problems.push({ kind: 'KEY', msg: `Key "${key}" not defined in root map`, at: src.indexOf(`${att}="${v}"`) });
          } else if (!S.keyspace) {
            problems.push({ kind: 'KEY', msg: `Key "${key}" used but no root map is set (Set root map to resolve keys)`, at: src.indexOf(`${att}="${v}"`) });
          }
        }
      }
    }
  } else if (isMd(S.file) || isMdx(S.file)) {
    for (const p of window.LINT.checkMarkdown(src)) problems.push(p);
    const dir = P.dirname(S.file);
    const linkRe = /\]\(([^)#\s]+)[^)]*\)/g;
    let m, checked = 0;
    while ((m = linkRe.exec(src)) !== null && checked < 120) {
      const t = m[1];
      if (/^([a-z]+:)?\/\//i.test(t) || /^(mailto|tel|data):/i.test(t) || t.startsWith('@')) continue;
      checked++;
      const abs = P.resolve(P.join(dir, t));
      if (!(await existsCached(abs))) {
        const near = nearestProjectFile(t);
        const prob = { kind: 'LINK', msg: `Target not found: ${t}`, at: m.index };
        if (near) {
          const rel = P.relative(dir, near).split(P.sep).join('/');
          prob.msg += ` — did you mean ${rel}?`;
          prob.fix = { label: `Replace with ${rel}`, apply: txt => txt.replace(`(${t}`, `(${rel}`) };
        }
        problems.push(prob);
      }
    }
  } else if (ext === '.html' || ext === '.htm') {
    for (const p of window.LINT.checkHtml(src)) problems.push(p);
  }

  // resolve fixId -> fix object
  for (const p of problems) {
    if (!p.fix && p.fixId) {
      const f = window.LINT.resolveFix(p);
      if (f) p.fix = f;
    }
  }

  // in-editor squiggles
  const mdl = activeModel();
  if (mdl) {
    monaco.editor.setModelMarkers(mdl, 'ds', problems.map(p => {
      const at = Math.max(0, p.at || 0);
      const pos = mdl.getPositionAt(Math.min(at, mdl.getValueLength()));
      const lineLen = mdl.getLineLength(pos.lineNumber);
      return {
        severity: p.kind === 'XML' || p.kind === 'HTML' ? monaco.MarkerSeverity.Error : monaco.MarkerSeverity.Warning,
        startLineNumber: pos.lineNumber,
        startColumn: pos.column,
        endLineNumber: pos.lineNumber,
        endColumn: Math.min(pos.column + 24, lineLen + 1),
        message: `[${p.kind}] ${p.msg}${p.fix ? ' — fix available in Problems' : ''}`
      };
    }));
  }

  // fix-all bar
  const fixables = problems.filter(p => p.fix);
  bar.innerHTML = '';
  if (fixables.length) {
    const b = document.createElement('button');
    b.className = 'mini';
    b.textContent = `Fix all auto-fixable (${fixables.length})`;
    b.onclick = () => {
      let text = editor.value;
      const applied = new Set();
      for (const p of problems) {
        if (!p.fix) continue;
        const sig = p.fixId || p.fix.label;
        if (applied.has(sig)) continue;   // idempotent global fixes apply once
        applied.add(sig);
        text = p.fix.apply(text);
      }
      editor.value = text;
      toast(`Applied ${applied.size} fix${applied.size > 1 ? 'es' : ''}.`);
      scheduleValidation();
    };
    bar.appendChild(b);
  }

  out.innerHTML = '';
  if (!problems.length) {
    out.innerHTML = '<div class="prob-item ok">No problems found.</div>';
    badge.hidden = true;
  } else {
    badge.textContent = problems.length;
    badge.hidden = false;
    for (const p of problems) {
      const d = document.createElement('div');
      d.className = 'prob-item';
      d.innerHTML = `<span class="prob-kind">${p.kind}</span>${escHtml(p.msg)}`;
      if (p.fix) {
        const fb = document.createElement('button');
        fb.className = 'mini prob-fix';
        fb.textContent = 'Fix';
        fb.title = p.fix.label;
        fb.onclick = e => {
          e.stopPropagation();
          editor.value = p.fix.apply(editor.value);
          toast(p.fix.label);
          scheduleValidation();
        };
        d.appendChild(fb);
      }
      d.onclick = () => jumpTo(Math.max(0, p.at || 0));
      out.appendChild(d);
    }
  }
  $('rightTitle').textContent = $('problemsPane').hidden ? $('rightTitle').textContent : 'PROBLEMS';
}

/* ---------------- outline ---------------- */

function renderOutline() {
  const out = $('outlineOut');
  out.innerHTML = '';
  if (!S.file) { out.innerHTML = '<div class="dep-none">Open a file first.</div>'; return; }
  const src = editor.value;
  const items = [];
  if (isDita(S.file)) {
    const doc = new DOMParser().parseFromString(src, 'application/xml');
    if (doc.querySelector('parsererror')) {
      out.innerHTML = '<div class="dep-none">XML does not parse; fix Problems first.</div>';
      return;
    }
    let searchFrom = 0;
    (function walk(el, depth) {
      for (const ch of el.children) {
        if (['title', 'glossterm', 'mainbooktitle', 'navtitle'].includes(ch.tagName) && ch.parentNode === el) {
          const text = ch.textContent.trim();
          const at = src.indexOf(text, searchFrom);
          if (at >= 0) searchFrom = at;
          items.push({ depth, tag: el.tagName, text, at: at >= 0 ? at : 0 });
        }
        walk(ch, depth + 1);
      }
    })(doc.documentElement, 0);
  } else {
    const re = /^(#{1,6})\s+(.+)$/gm;
    let m;
    while ((m = re.exec(src)) !== null) {
      items.push({ depth: m[1].length - 1, tag: 'h' + m[1].length, text: m[2].trim(), at: m.index });
    }
  }
  if (!items.length) { out.innerHTML = '<div class="dep-none">No headings found.</div>'; return; }
  for (const it of items) {
    const d = document.createElement('div');
    d.className = 'out-item';
    d.style.paddingLeft = 6 + it.depth * 14 + 'px';
    d.innerHTML = `<span class="out-tag">${escHtml(it.tag)}</span>${escHtml(it.text.slice(0, 80))}`;
    d.onclick = () => jumpTo(it.at);
    out.appendChild(d);
  }
}

/* ---------------- find in files ---------------- */

$('btnSearchGo').onclick = runSearch;
$('searchInput').addEventListener('keydown', e => { if (e.key === 'Enter') runSearch(); });

async function runSearch() {
  const q = $('searchInput').value;
  const out = $('searchOut');
  if (!S.root) { out.innerHTML = '<div class="dep-none">Open a folder first.</div>'; return; }
  if (!q || q.length < 2) { out.innerHTML = '<div class="dep-none">Type at least 2 characters.</div>'; return; }
  out.innerHTML = '<div class="dep-none">Searching…</div>';
  const scope = $('searchScope').value;
  const caseSensitive = $('searchCase').checked;
  const files = await getProjectFiles();
  const needle = caseSensitive ? q : q.toLowerCase();
  let hits = 0;
  out.innerHTML = '';
  for (const f of files) {
    const e = extOf(f.path);
    if (scope === 'dita' && !['.dita', '.ditamap', '.bookmap', '.xml'].includes(e)) continue;
    if (scope === 'md' && !['.md', '.mdx', '.markdown'].includes(e)) continue;
    const hay = caseSensitive ? f.content : f.content.toLowerCase();
    if (!hay.includes(needle)) continue;
    const header = document.createElement('div');
    header.className = 'sr-file';
    header.textContent = P.relative(S.root, f.path);
    out.appendChild(header);
    const lines = f.content.split('\n');
    let offset = 0;
    for (let i = 0; i < lines.length && hits < 400; i++) {
      const lineHay = caseSensitive ? lines[i] : lines[i].toLowerCase();
      const col = lineHay.indexOf(needle);
      if (col >= 0) {
        hits++;
        const at = offset + col;
        const d = document.createElement('div');
        d.className = 'sr-line';
        const line = lines[i];
        d.innerHTML = `<span class="sr-ln">${i + 1}</span>` +
          escHtml(line.slice(0, col)) + `<span class="sr-hit">${escHtml(line.substr(col, q.length))}</span>` +
          escHtml(line.slice(col + q.length)).slice(0, 120);
        d.onclick = async () => { await openFile(f.path); jumpTo(at); };
        out.appendChild(d);
      }
      offset += lines[i].length + 1;
    }
    if (hits >= 400) break;
  }
  if (!hits) out.innerHTML = '<div class="dep-none">No matches.</div>';
}

/* ---------------- map browser + drag & drop ---------------- */

const REF_TAGS = new Set([
  'topicref', 'mapref', 'topichead', 'topicgroup', 'keydef', 'glossref',
  'chapter', 'part', 'appendix', 'appendices', 'preface', 'notices',
  'frontmatter', 'backmatter', 'dedication', 'colophon', 'amendments',
  'bookabstract', 'draftintro', 'topicsetref', 'topicset', 'anchorref'
]);

function refreshMapModel() {
  if (!S.file || !isMap(S.file)) { S.mapDoc = null; $('btnMapApply').disabled = true; return; }
  const src = editor.value;
  const m = src.match(/^[\s\S]*?(<(?:map|bookmap)[\s>])/);
  S.mapProlog = m ? src.slice(0, src.indexOf(m[1])) : '<?xml version="1.0" encoding="UTF-8"?>\n';
  const doc = new DOMParser().parseFromString(src, 'application/xml');
  S.mapDoc = doc.querySelector('parsererror') ? null : doc;
  $('btnMapApply').disabled = !S.mapDoc;
  if (!$('mapPane').hidden) renderMapTree();
}

function mapRowLabel(el) {
  const href = el.getAttribute('href');
  const keys = el.getAttribute('keys');
  const nav = el.getAttribute('navtitle') ||
    (el.querySelector(':scope > topicmeta > navtitle') || {}).textContent;
  let s = `<span class="mtag">&lt;${el.tagName}&gt;</span>`;
  if (href) s += ` <span class="mhref">${escHtml(href)}</span>`;
  if (keys) s += ` <span class="mnav">keys="${escHtml(keys)}"</span>`;
  if (nav) s += ` <span class="mnav">${escHtml(nav)}</span>`;
  return s;
}

function renderMapTree() {
  const host = $('mapTree');
  host.innerHTML = '';
  if (!S.file || !isMap(S.file)) {
    host.innerHTML = '<div class="dep-none">Current file is not a .ditamap / .bookmap.</div>';
    return;
  }
  if (!S.mapDoc) {
    host.innerHTML = '<div class="dep-none">Map XML does not parse — fix it in the editor first.</div>';
    return;
  }
  host.appendChild(buildMapNodes(S.mapDoc.documentElement));
}

function buildMapNodes(parentEl) {
  const frag = document.createDocumentFragment();
  for (const el of Array.from(parentEl.children)) {
    if (!REF_TAGS.has(el.tagName)) {
      if (['title', 'booktitle', 'topicmeta', 'bookmeta'].includes(el.tagName)) {
        const fixed = document.createElement('div');
        fixed.className = 'mrow mfixed';
        fixed.innerHTML = `<span class="mtag">&lt;${el.tagName}&gt;</span> <span class="mnav">${escHtml((el.textContent || '').trim().slice(0, 60))}</span>`;
        frag.appendChild(fixed);
      }
      continue;
    }
    const wrap = document.createElement('div');
    const row = document.createElement('div');
    row.className = 'mrow';
    row.draggable = true;
    row.innerHTML = mapRowLabel(el);
    row._el = el;
    attachDnD(row);
    wrap.appendChild(row);
    const kidRefs = Array.from(el.children).some(k => REF_TAGS.has(k.tagName));
    if (kidRefs) {
      const kids = document.createElement('div');
      kids.className = 'mkids';
      kids.appendChild(buildMapNodes(el));
      wrap.appendChild(kids);
    }
    frag.appendChild(wrap);
  }
  return frag;
}

let dragEl = null;

function hasFileDrag(e) {
  return Array.from(e.dataTransfer.types || []).includes('text/ds-path');
}

/* Build the right ref element for a file, relative to a given map */
const MAP_ADDABLE = ['.dita', '.xml', '.md', '.mdx', '.markdown', '.ditamap', '.bookmap'];

function makeRefEl(doc, mapPath, filePath, parentTag) {
  const rel = P.relative(P.dirname(mapPath), filePath).split(P.sep).join('/');
  const ext = extOf(filePath);
  let tag = 'topicref';
  if (ext === '.ditamap' || ext === '.bookmap') tag = 'mapref';
  else if (parentTag === 'bookmap') tag = 'chapter';
  const el = doc.createElement(tag);
  el.setAttribute('href', rel);
  if (['.md', '.markdown'].includes(ext)) el.setAttribute('format', 'markdown'); // MDITA / Markdown per DITA-OT
  else if (ext === '.mdx') el.setAttribute('format', 'mdx');
  else if (ext === '.ditamap' || ext === '.bookmap') el.setAttribute('format', 'ditamap');
  return el;
}

function insertDroppedFile(filePath, targetEl, zone) {
  if (!S.mapDoc) { toast('Fix the map XML first.'); return; }
  if (!MAP_ADDABLE.includes(extOf(filePath))) {
    toast('Only DITA / LwDITA / Markdown / MDX / map files can be added to a map.');
    return;
  }
  if (!depthAllows(targetEl, zone, null)) return;
  let ref;
  if (zone === 'inside' || !targetEl) {
    const parent = targetEl || S.mapDoc.documentElement;
    ref = makeRefEl(S.mapDoc, S.file, filePath, parent.tagName);
    parent.appendChild(ref);
  } else {
    ref = makeRefEl(S.mapDoc, S.file, filePath, targetEl.parentNode.tagName);
    if (zone === 'before') targetEl.parentNode.insertBefore(ref, targetEl);
    else targetEl.parentNode.insertBefore(ref, targetEl.nextSibling);
  }
  writeMapToEditor();
  renderMapTree();
  toast('Added ' + P.basename(filePath) + ' to map.');
}

/* Add a file to any map in the project — works whether or not that map is open */
async function addFileToMap(mapPath, filePath) {
  if (!MAP_ADDABLE.includes(extOf(filePath))) {
    toast('Only DITA / LwDITA / Markdown / MDX / map files can be added to a map.');
    return false;
  }
  if (P.resolve(mapPath) === P.resolve(filePath)) { toast('A map cannot include itself.'); return false; }
  // if this map is the open file, go through the live model so the editor stays in sync
  if (S.file && P.resolve(S.file) === P.resolve(mapPath)) {
    if (!S.mapDoc) { toast('The open map has XML errors — fix them first.'); return false; }
    insertDroppedFile(filePath, null, 'inside');
    return true;
  }
  try {
    const src = await window.api.readFile(mapPath);
    const m = src.match(/^[\s\S]*?(<(?:map|bookmap)[\s>])/);
    const prolog = m ? src.slice(0, src.indexOf(m[1])) : '<?xml version="1.0" encoding="UTF-8"?>\n';
    const doc = new DOMParser().parseFromString(src, 'application/xml');
    if (doc.querySelector('parsererror')) { toast(P.basename(mapPath) + ' has XML errors — open and fix it first.'); return false; }
    const root = doc.documentElement;
    root.appendChild(makeRefEl(doc, mapPath, filePath, root.tagName));
    await window.api.writeFile(mapPath, prolog + serializeXml(root, 0));
    S.fileCache.delete(mapPath);
    S.depIndex = null;
    toast(`Added ${P.basename(filePath)} to ${P.basename(mapPath)}.`);
    return true;
  } catch (e) {
    toast('Could not update map: ' + e.message);
    return false;
  }
}

/* list all maps in the project tree */
function projectMaps() {
  const maps = [];
  (function walk(nodes) {
    for (const n of nodes) {
      if (n.dir) walk(n.children || []);
      else if (isMap(n.path)) maps.push(n.path);
    }
  })(S.tree || []);
  return maps;
}

function attachDnD(row) {
  row.addEventListener('dragstart', e => {
    dragEl = row._el;
    row.classList.add('dragging');
    e.dataTransfer.effectAllowed = 'move';
    e.stopPropagation();
  });
  row.addEventListener('dragend', () => {
    row.classList.remove('dragging');
    dragEl = null;
    document.querySelectorAll('.mrow').forEach(r => r.classList.remove('drop-before', 'drop-after', 'drop-inside', 'drop-file'));
  });
  row.addEventListener('dragover', e => {
    if (hasFileDrag(e)) {
      e.preventDefault();
      e.stopPropagation();
      const zone = dropZone(row, e);
      row.classList.add('drop-file');
      row.classList.toggle('drop-before', zone === 'before');
      row.classList.toggle('drop-after', zone === 'after');
      row.classList.toggle('drop-inside', zone === 'inside');
      return;
    }
    if (!dragEl || row._el === dragEl || dragEl.contains(row._el)) return;
    e.preventDefault();
    const zone = dropZone(row, e);
    row.classList.toggle('drop-before', zone === 'before');
    row.classList.toggle('drop-after', zone === 'after');
    row.classList.toggle('drop-inside', zone === 'inside');
    e.stopPropagation();
  });
  row.addEventListener('dragleave', () => {
    row.classList.remove('drop-before', 'drop-after', 'drop-inside', 'drop-file');
  });
  row.addEventListener('drop', e => {
    e.preventDefault();
    e.stopPropagation();
    row.classList.remove('drop-file');
    if (hasFileDrag(e)) {
      insertDroppedFile(e.dataTransfer.getData('text/ds-path'), row._el, dropZone(row, e));
      return;
    }
    if (!dragEl || row._el === dragEl || dragEl.contains(row._el)) return;
    const zone = dropZone(row, e);
    const target = row._el;
    if (!depthAllows(target, zone, dragEl)) return;
    if (zone === 'before') target.parentNode.insertBefore(dragEl, target);
    else if (zone === 'after') target.parentNode.insertBefore(dragEl, target.nextSibling);
    else target.appendChild(dragEl);
    writeMapToEditor();
    renderMapTree();
  });
  row.addEventListener('contextmenu', e => {
    e.preventDefault();
    e.stopPropagation();
    mapRowContextMenu(row._el, e.clientX, e.clientY);
  });
}

/* drop on empty map-tree area = append to map root */
$('mapTree').addEventListener('dragover', e => {
  if (hasFileDrag(e)) { e.preventDefault(); $('mapTree').classList.add('drop-file-root'); }
});
$('mapTree').addEventListener('dragleave', () => $('mapTree').classList.remove('drop-file-root'));
$('mapTree').addEventListener('drop', e => {
  $('mapTree').classList.remove('drop-file-root');
  if (!hasFileDrag(e) || e.defaultPrevented) return;
  e.preventDefault();
  insertDroppedFile(e.dataTransfer.getData('text/ds-path'), null, 'inside');
});

function dropZone(row, e) {
  const r = row.getBoundingClientRect();
  const y = (e.clientY - r.top) / r.height;
  if (y < 0.25) return 'before';
  if (y > 0.75) return 'after';
  return 'inside';
}

/* nesting depth helpers: root-level refs are depth 1; max 5 per spec */
const MAX_REF_DEPTH = 5;
function refDepth(el) {
  let d = 0, cur = el;
  while (cur && cur.nodeType === 1 && REF_TAGS.has(cur.tagName)) { d++; cur = cur.parentNode; }
  return d;
}
function subtreeHeight(el) {
  let h = 1;
  for (const ch of el.children) {
    if (REF_TAGS.has(ch.tagName)) h = Math.max(h, 1 + subtreeHeight(ch));
  }
  return h;
}
function depthAllows(targetEl, zone, movingEl) {
  const baseDepth = !targetEl ? 0 : (zone === 'inside' ? refDepth(targetEl) : refDepth(targetEl) - 1);
  const height = movingEl ? subtreeHeight(movingEl) : 1;
  if (baseDepth + height > MAX_REF_DEPTH) {
    toast(`Nesting limit: references can go at most ${MAX_REF_DEPTH} levels deep.`);
    return false;
  }
  return true;
}

function serializeXml(node, indent) {
  const pad = '  '.repeat(indent);
  if (node.nodeType === 3) {
    const t = node.nodeValue.trim();
    return t ? pad + escXml(t) + '\n' : '';
  }
  if (node.nodeType === 8) return `${pad}<!--${node.nodeValue}-->\n`;
  if (node.nodeType !== 1) return '';
  let attrs = '';
  for (const a of Array.from(node.attributes)) attrs += ` ${a.name}="${escXml(a.value)}"`;
  const kids = Array.from(node.childNodes).filter(n =>
    n.nodeType === 1 || n.nodeType === 8 || (n.nodeType === 3 && n.nodeValue.trim()));
  if (!kids.length) return `${pad}<${node.tagName}${attrs}/>\n`;
  if (kids.length === 1 && kids[0].nodeType === 3) {
    return `${pad}<${node.tagName}${attrs}>${escXml(kids[0].nodeValue.trim())}</${node.tagName}>\n`;
  }
  let out = `${pad}<${node.tagName}${attrs}>\n`;
  for (const k of kids) out += serializeXml(k, indent + 1);
  out += `${pad}</${node.tagName}>\n`;
  return out;
}
function escXml(s) {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function writeMapToEditor() {
  if (!S.mapDoc) return;
  editor.value = S.mapProlog + serializeXml(S.mapDoc.documentElement, 0);
  setDirty(true);
  schedulePreview();
  scheduleValidation();
}
$('btnMapApply').onclick = writeMapToEditor;

/* ---------------- dependencies ---------------- */

$('btnDeps').onclick = () => setRightMode('deps');
$('btnDepsRefresh').onclick = async () => { await buildDepIndex(); renderDeps(); };

async function getProjectFiles(force) {
  const now = Date.now();
  if (!force && S._pf && now - S._pf.at < 15000) return S._pf.files;
  const files = await window.api.collectAuthoringFiles(S.root);
  S._pf = { files, at: now };
  return files;
}

async function buildDepIndex() {
  if (!S.root) return;
  toast('Indexing project references…');
  const files = await getProjectFiles();
  S.depIndex = window.DEPS.build(files, P);
  toast(`Indexed ${files.length} files.`);
  updateBacklinks();
}

async function renderDeps() {
  const out = $('depsOut');
  if (!S.file) { out.innerHTML = '<div class="dep-none">Open a file first.</div>'; return; }
  if (!S.depIndex) await buildDepIndex();
  if (!S.depIndex) { out.innerHTML = '<div class="dep-none">No project open.</div>'; return; }

  const key = P.resolve(S.file);
  const fwd = S.depIndex.forward.get(key) || [];
  const rev = S.depIndex.reverse.get(key) || [];
  out.innerHTML = '';

  const h1 = document.createElement('div');
  h1.className = 'dep-h';
  h1.textContent = `THIS FILE REFERENCES (${fwd.length})`;
  out.appendChild(h1);
  if (!fwd.length) out.insertAdjacentHTML('beforeend', '<div class="dep-none">none</div>');
  for (const r of fwd) {
    const d = document.createElement('div');
    d.className = 'dep-item';
    const label = r.resolved ? P.relative(S.root, r.resolved) : r.target;
    const miss = r.resolved && r.exists === false ? ' <span class="dep-missing">[missing]</span>' : '';
    const sym = r.symbolic ? ' <span class="dep-kind">(key/package — not path-resolved)</span>' : '';
    d.innerHTML = `<span class="dep-kind">${r.kind}</span>${escHtml(label)}${miss}${sym}`;
    if (r.resolved && r.exists) d.onclick = () => openFile(r.resolved);
    out.appendChild(d);
  }

  const h2 = document.createElement('div');
  h2.className = 'dep-h';
  h2.textContent = `REFERENCED BY (${rev.length})`;
  out.appendChild(h2);
  if (!rev.length) out.insertAdjacentHTML('beforeend', '<div class="dep-none">none — safe to move or rename</div>');
  for (const r of rev) {
    const d = document.createElement('div');
    d.className = 'dep-item';
    d.innerHTML = `<span class="dep-kind">${r.kind}</span>${escHtml(P.relative(S.root, r.from))}`;
    d.onclick = () => openFile(r.from);
    out.appendChild(d);
  }
}

/* ---------------- export ---------------- */

async function buildExportDoc() {
  const dir = P.dirname(S.file);
  if (isMap(S.file)) {
    const a = await assembleMap(S.file, editor.value);
    return { html: publishDoc(a.title, a.body, dir, 'light'), name: P.basename(S.file, extOf(S.file)) };
  }
  const body = (await buildBodyHtml(S.file, editor.value)) || '';
  return { html: publishDoc(P.basename(S.file), body, dir, 'light'), name: P.basename(S.file, extOf(S.file)) };
}

$('btnExportHTML').onclick = async () => {
  if (!S.file) return;
  const { html, name } = await buildExportDoc();
  const p = await window.api.exportHTML(html, name + '.html');
  if (p) { toast('HTML exported.'); window.api.showInFolder(p); }
};

$('btnExportPDF').onclick = async () => {
  if (!S.file) return;
  const { html, name } = await buildExportDoc();
  const p = await window.api.exportPDF(html, name + '.pdf');
  if (p) { toast('PDF exported.'); window.api.showInFolder(p); }
};

/* ---------------- autosave (interval configurable, default 3 minutes) ---------------- */

async function autosaveTick() {
  if (S.root && TABS.list.length) {
    let saved = 0;
    for (const t of TABS.list) {
      const content = t.model.getValue();
      if (content === t.lastAutosaved) continue;
      try {
        await window.api.autosaveSave(S.root, t.path, content);
        t.lastAutosaved = content;
        saved++;
      } catch (e) { /* per-file failure shouldn't stop the loop */ }
    }
    if (saved) $('autosaveStatus').textContent = 'autosave: ' + new Date().toLocaleTimeString();
  }
  setTimeout(autosaveTick, Math.max(1, SETTINGS.autosaveMin) * 60 * 1000);
}

/* versions: load or diff-compare */
let diffEditor = null;
let diffLoadedText = null;

function openVersionDiff(snapshotText, stamp) {
  diffLoadedText = snapshotText;
  $('diffTitle').textContent = `Autosaved ${stamp}  ↔  current editor content`;
  $('dlgDiff').showModal();
  if (!diffEditor) {
    diffEditor = monaco.editor.createDiffEditor($('diffHost'), {
      theme: 'vs-dark', automaticLayout: true, readOnly: true,
      renderSideBySide: true, fontSize: SETTINGS.fontSize
    });
  }
  const lang = S.file ? langFor(S.file) : 'plaintext';
  diffEditor.setModel({
    original: monaco.editor.createModel(snapshotText, lang),
    modified: monaco.editor.createModel(editor.value, lang)
  });
}

$('btnDiffClose').onclick = () => {
  const m = diffEditor && diffEditor.getModel();
  $('dlgDiff').close();
  if (m) { m.original.dispose(); m.modified.dispose(); }
};
$('btnDiffLoad').onclick = () => {
  if (diffLoadedText != null) {
    editor.value = diffLoadedText;
    toast('Version loaded — press Ctrl+S to keep it, Ctrl+Z to undo.');
  }
  $('btnDiffClose').click();
  $('dlgVersions').close();
};

$('btnVersions').onclick = async () => {
  const list = await window.api.autosaveList(S.root, S.file);
  const host = $('versionList');
  host.innerHTML = list.length ? '' : '<div class="dep-none">No autosaved versions yet (snapshots are taken on the autosave interval while editing).</div>';
  for (const v of list) {
    const row = document.createElement('div');
    row.className = 'version-item';
    const stamp = (v.name.match(/(\d{8}-\d{6})\.bak$/) || [])[1] || v.name;
    row.innerHTML = `<span>${stamp}</span>`;
    const btns = document.createElement('span');
    const cmp = document.createElement('button');
    cmp.textContent = 'Compare';
    cmp.onclick = async () => openVersionDiff(await window.api.readFile(v.path), stamp);
    const b = document.createElement('button');
    b.textContent = 'Load';
    b.style.marginLeft = '6px';
    b.onclick = async () => {
      editor.value = await window.api.readFile(v.path);
      $('dlgVersions').close();
      toast('Version loaded — press Ctrl+S to keep it, Ctrl+Z to undo.');
    };
    btns.appendChild(cmp);
    btns.appendChild(b);
    row.appendChild(btns);
    host.appendChild(row);
  }
  $('dlgVersions').showModal();
};
$('btnVersionsClose').onclick = () => $('dlgVersions').close();

window.addEventListener('beforeunload', e => {
  if (TABS.list.some(t => t.dirty)) { e.preventDefault(); e.returnValue = ''; }
});

/* ================================================================
   v1.2 additions: settings, style packs, context menus, DITA-OT
   ================================================================ */

/* ---------------- settings ---------------- */

const SETTINGS = Object.assign({
  fontSize: 13,
  tabWidth: 2,
  wordWrap: false,
  autoCloseTags: true,
  autosaveMin: 3,
  stylePack: 'default',
  customCss: '',
  otDir: '',
  otTranstype: 'html5'
}, (() => { try { return JSON.parse(localStorage.getItem('ds:settings') || '{}'); } catch (e) { return {}; } })());

function saveSettings() {
  localStorage.setItem('ds:settings', JSON.stringify(SETTINGS));
}

async function applySettings() {
  monacoEd.updateOptions({
    fontSize: SETTINGS.fontSize,
    tabSize: SETTINGS.tabWidth,
    insertSpaces: true,
    wordWrap: SETTINGS.wordWrap ? 'on' : 'off'
  });
  S.customCssText = '';
  if (SETTINGS.customCss) {
    try { S.customCssText = await window.api.readFile(SETTINGS.customCss); }
    catch (e) { S.customCssText = ''; }
  }
  schedulePreview();
}

const STYLE_PACKS = {
  default: '',
  portal: `
    body{max-width:860px;margin:0 auto;font-size:15.5px}
    h1{border-bottom:none;color:#0d5c8c;font-weight:650}
    h2{color:#0d5c8c;border-bottom:1px solid #e1e5ea;padding-bottom:.2em}
    .d-note{border-radius:6px}
    pre,.d-code{border-radius:8px}
    a{text-decoration:none}a:hover{text-decoration:underline}`,
  print: `
    body{font-family:Georgia,"Times New Roman",serif;font-size:14.5px;line-height:1.7;max-width:760px;margin:0 auto}
    h1,h2,h3{font-family:Georgia,serif;font-weight:700}
    h1{border-bottom:1px solid #444;color:#222}
    code,kbd,samp,pre,.d-code{font-size:.88em}
    .d-note{background:none;border:1px solid #999;border-left-width:4px}`,
  compact: `
    body{font-size:13.5px;line-height:1.45;padding:18px 22px}
    h1{font-size:1.4em}h2{font-size:1.15em;margin-top:1.1em}h3{font-size:1em}
    p{margin:.5em 0}.d-steps>li{margin:4px 0}
    table.d-table th,table.d-table td{padding:3px 7px}`,
  ledger: `
    body{max-width:840px;margin:0 auto}
    h1{border-bottom:3px solid #1256a0;color:#123a63}
    h2{color:#1256a0}h3{color:#123a63}
    a{color:#1256a0}
    .d-note{border-left-color:#1256a0;background:#f0f5fb}
    .d-note-warning,.d-note-caution,.d-note-danger{border-left-color:#c0564a;background:#fbf3f2}
    code,kbd,samp,pre,.d-code{background:#eef3f8;border-color:#d7e2ee}
    .d-table th{background:#eef3f8}`,
  handbook: `
    body{max-width:720px;margin:0 auto;font-size:15.5px;line-height:1.75}
    h1,h2,h3{font-family:Georgia,"Times New Roman",serif;letter-spacing:.01em}
    h1{font-size:2em;border-bottom:1px solid #b9a06b;color:#3d2f14}
    h2{color:#5a4620}
    .shortdesc{font-style:italic}
    .d-note{border-left-color:#b9a06b;background:#faf7f0}`,
  terminal: `
    body{font-family:Consolas,"Cascadia Code",monospace;font-size:13.5px;max-width:880px;margin:0 auto}
    h1{border-bottom:2px dashed #2a9d63;color:#1d7a4b}
    h2{color:#1d7a4b}h2::before{content:"## "}h3::before{content:"### "}
    a{color:#1d7a4b}
    .d-note{border-left-color:#2a9d63}
    .d-label{color:#1d7a4b}`
};

/* settings dialog wiring */
$('btnSettings').onclick = () => {
  $('setFont').value = SETTINGS.fontSize;
  $('setTab').value = SETTINGS.tabWidth;
  $('setWrap').checked = SETTINGS.wordWrap;
  $('setAutoClose').checked = SETTINGS.autoCloseTags;
  $('setAutosave').value = SETTINGS.autosaveMin;
  $('setStylePack').value = SETTINGS.stylePack;
  $('setCustomCss').value = SETTINGS.customCss;
  $('setOtDir').value = SETTINGS.otDir;
  $('setTranstype').value = SETTINGS.otTranstype;
  $('dlgSettings').showModal();
};

function bindSetting(id, key, kind) {
  $(id).addEventListener('change', async () => {
    const el = $(id);
    SETTINGS[key] = kind === 'bool' ? el.checked : kind === 'num' ? +el.value : el.value;
    saveSettings();
    await applySettings();
  });
}
bindSetting('setFont', 'fontSize', 'num');
bindSetting('setTab', 'tabWidth', 'num');
bindSetting('setWrap', 'wordWrap', 'bool');
bindSetting('setAutoClose', 'autoCloseTags', 'bool');
bindSetting('setAutosave', 'autosaveMin', 'num');
bindSetting('setStylePack', 'stylePack', 'str');
bindSetting('setTranstype', 'otTranstype', 'str');

$('btnPickCss').onclick = async () => {
  const f = await window.api.pickFile('Choose a custom stylesheet', [{ name: 'CSS', extensions: ['css'] }]);
  if (f) { SETTINGS.customCss = f; $('setCustomCss').value = f; saveSettings(); await applySettings(); }
};
$('btnClearCss').onclick = async () => {
  SETTINGS.customCss = ''; $('setCustomCss').value = ''; saveSettings(); await applySettings();
};
$('btnPickOt').onclick = async () => {
  const d = await window.api.pickFolder('Choose your DITA-OT install folder (contains bin/)');
  if (d) { SETTINGS.otDir = d; $('setOtDir').value = d; saveSettings(); }
};
$('btnSettingsClose').onclick = () => $('dlgSettings').close();

/* ---------------- context menu framework ---------------- */

const ctxHost = $('ctxMenu');

function renderMenuItems(items, x, y, parentItems) {
  ctxHost.innerHTML = '';
  if (parentItems) {
    const back = document.createElement('div');
    back.className = 'ctx-item';
    back.innerHTML = '<span>‹ Back</span>';
    back.onclick = e => { e.stopPropagation(); renderMenuItems(parentItems, x, y, null); };
    ctxHost.appendChild(back);
    ctxHost.appendChild(Object.assign(document.createElement('div'), { className: 'ctx-sep' }));
  }
  for (const it of items) {
    if (it === '-') {
      ctxHost.appendChild(Object.assign(document.createElement('div'), { className: 'ctx-sep' }));
      continue;
    }
    const d = document.createElement('div');
    d.className = 'ctx-item' + (it.disabled ? ' disabled' : '');
    const check = it.checked !== undefined ? `<span class="ctx-check">${it.checked ? '✓' : ''}</span>` : '';
    const hint = it.sub ? '<span class="ctx-hint">▸</span>' : (it.hint ? `<span class="ctx-hint">${it.hint}</span>` : '');
    d.innerHTML = `<span>${check}${escHtml(it.label)}</span>${hint}`;
    d.onclick = e => {
      if (it.sub) { e.stopPropagation(); renderMenuItems(it.sub, x, y, items); return; }
      hideContextMenu();
      it.run && it.run();
    };
    ctxHost.appendChild(d);
  }
  ctxHost.hidden = false;
  ctxHost.style.left = '0px'; ctxHost.style.top = '0px'; // measure at origin
  const r = ctxHost.getBoundingClientRect();
  ctxHost.style.left = Math.min(x, window.innerWidth - r.width - 8) + 'px';
  ctxHost.style.top = Math.min(y, window.innerHeight - r.height - 8) + 'px';
}

function showContextMenu(items, x, y) { renderMenuItems(items, x, y, null); }

function hideContextMenu() {
  ctxHost.hidden = true;
  document.querySelectorAll('.mb-item.open').forEach(b => b.classList.remove('open'));
  menubarOpen = null;
}
document.addEventListener('click', hideContextMenu);
document.addEventListener('keydown', e => { if (e.key === 'Escape') hideContextMenu(); });
window.addEventListener('blur', hideContextMenu);

/* ---------------- tree context menu ---------------- */

function treeContextMenu(n, x, y) {
  const items = [];
  if (!n.dir) {
    items.push({ label: 'Open', run: () => openFile(n.path) });
    if (MAP_ADDABLE.includes(extOf(n.name))) {
      if (S.file && isMap(S.file)) {
        items.push({ label: 'Add to current map', run: () => insertDroppedFile(n.path, null, 'inside') });
      }
      items.push({
        label: 'Add to map…',
        disabled: !projectMaps().filter(m => P.resolve(m) !== P.resolve(n.path)).length,
        run: async () => {
          const maps = projectMaps().filter(m => P.resolve(m) !== P.resolve(n.path));
          const pick = await pickFromList('Add "' + n.name + '" to which map?',
            maps.map(m => ({ label: P.relative(S.root, m), value: m })));
          if (pick) await addFileToMap(pick, n.path);
        }
      });
    }
    if (isMap(n.path)) {
      items.push({
        label: 'Set as root map (key space)',
        run: async () => {
          S.rootMap = P.resolve(n.path);
          saveProjectPrefs();
          await buildKeyspace();
          updateRootMapStatus();
          toast('Root map set: ' + n.name);
          schedulePreview(); scheduleValidation();
        }
      });
    }
    items.push('-');
  }
  items.push(
    { label: 'New file here…', run: () => { S.pendingInsert = null; openNewFileDialog(n.dir ? n.path : P.dirname(n.path)); } },
    { label: 'New folder here…', run: async () => {
        const base = n.dir ? n.path : P.dirname(n.path);
        const name = prompt('New folder name:', 'topics');
        if (name) { await window.api.createFolder(P.join(base, name)); refreshTree(); }
      } },
    '-',
    { label: 'Rename…', run: () => renameNode(n) },
    { label: 'Delete', run: () => deleteNode(n) },
    '-',
    { label: 'Reveal in File Explorer', run: () => window.api.showInFolder(n.path) },
    { label: 'Copy full path', run: () => { navigator.clipboard.writeText(n.path); toast('Path copied.'); } },
    { label: 'Copy project-relative path', run: () => { navigator.clipboard.writeText(P.relative(S.root, n.path).split(P.sep).join('/')); toast('Relative path copied.'); } }
  );
  showContextMenu(items, x, y);
}

/* ---------------- editor context menu (insert helpers) ---------------- */

function wrapSelection(before, after) {
  const sel = monacoEd.getSelection();
  const m = activeModel();
  if (!sel || !m) return;
  const text = m.getValueInRange(sel);
  monacoEd.executeEdits('ds-wrap', [{ range: sel, text: before + text + after, forceMoveMarkers: true }]);
  monacoEd.focus();
}

$('editor').addEventListener('contextmenu', e => {
  if (!activeTab()) return;
  e.preventDefault();
  const items = [
    { label: 'AI: improve selection', run: () => { setRightMode('ai'); $('aiAction').value = 'improve'; $('aiRun').click(); } },
    '-',
    { label: 'Cut', run: () => document.execCommand('cut') },
    { label: 'Copy', run: () => document.execCommand('copy') },
    { label: 'Paste', run: async () => {
        const t = await navigator.clipboard.readText();
        insertAtCaret(t);
      } },
    { label: 'Select all', run: () => { editor.focus(); editor.select(); } },
    '-'
  ];
  if (S.file && isDita(S.file)) {
    items.push(
      { label: 'Wrap in <b>', run: () => wrapSelection('<b>', '</b>') },
      { label: 'Wrap in <codeph>', run: () => wrapSelection('<codeph>', '</codeph>') },
      { label: 'Wrap in <uicontrol>', run: () => wrapSelection('<uicontrol>', '</uicontrol>') },
      '-',
      { label: 'Insert <note>', run: () => insertAtCaret('<note type="note"></note>') },
      { label: 'Insert <codeblock>', run: () => insertAtCaret('<codeblock></codeblock>') },
      { label: 'Insert <xref>', run: () => insertAtCaret('<xref href=""></xref>') },
      { label: 'Insert table…', run: openTableDialog },
      { label: 'Insert image…', run: insertImageFile },
      { label: 'Insert video / audio…', run: insertLocalMedia },
      { label: 'Embed online media…', run: () => { $('embedUrl').value = ''; $('dlgEmbed').showModal(); } },
      { label: 'Insert <steps>', run: () => insertAtCaret('<steps>\n  <step><cmd></cmd></step>\n</steps>') }
    );
  } else if (S.file && (isMd(S.file) || isMdx(S.file))) {
    items.push(
      { label: 'Wrap in **bold**', run: () => wrapSelection('**', '**') },
      { label: 'Wrap in `code`', run: () => wrapSelection('`', '`') },
      '-',
      { label: 'Insert code fence', run: () => insertAtCaret('\n```\n\n```\n') },
      { label: 'Insert link', run: () => insertAtCaret('[text](url)') },
      { label: 'Insert table…', run: openTableDialog },
      { label: 'Insert image…', run: insertImageFile },
      { label: 'Insert video / audio…', run: insertLocalMedia },
      { label: 'Embed online media…', run: () => { $('embedUrl').value = ''; $('dlgEmbed').showModal(); } }
    );
  }
  showContextMenu(items, e.clientX, e.clientY);
});

/* ---------------- map row context menu ---------------- */

function mapRowContextMenu(el, x, y) {
  showContextMenu([
    { label: 'Open target', disabled: !el.getAttribute('href'), run: () => {
        const h = el.getAttribute('href');
        if (h) openFile(P.resolve(P.join(P.dirname(S.file), h.split('#')[0])));
      } },
    '-',
    { label: 'New child topic…', run: () => {
        S.pendingInsert = el;
        openNewFileDialog(P.dirname(S.file));
      } },
    { label: 'Add child topicref…', run: () => {
        const h = prompt('href for the new child topicref:', 'topic.dita');
        if (!h) return;
        const ref = S.mapDoc.createElement('topicref');
        ref.setAttribute('href', h);
        el.appendChild(ref);
        writeMapToEditor(); renderMapTree();
      } },
    { label: 'Move up', disabled: !el.previousElementSibling, run: () => {
        el.parentNode.insertBefore(el, el.previousElementSibling);
        writeMapToEditor(); renderMapTree();
      } },
    { label: 'Move down', disabled: !el.nextElementSibling, run: () => {
        const next = el.nextElementSibling;
        el.parentNode.insertBefore(next, el);
        writeMapToEditor(); renderMapTree();
      } },
    '-',
    { label: 'Remove from map', run: () => {
        el.parentNode.removeChild(el);
        writeMapToEditor(); renderMapTree();
      } }
  ], x, y);
}

/* ---------------- DITA-OT publish ---------------- */

let otRunning = false;
window.api.onDitaotLog(chunk => {
  const log = $('otLog');
  log.textContent += chunk;
  log.scrollTop = log.scrollHeight;
});

$('btnPublishOT').onclick = async () => {
  if (!S.file) return;
  if (!SETTINGS.otDir) {
    toast('Set your DITA-OT install folder in Settings first.');
    $('btnSettings').click();
    return;
  }
  if (S.dirty) { await save(); }
  const outDir = await window.api.pickFolder('Choose an output folder for DITA-OT');
  if (!outDir) return;
  $('otLog').textContent = '';
  $('dlgOtLog').showModal();
  otRunning = true;
  const r = await window.api.ditaotRun(SETTINGS.otDir, S.file, SETTINGS.otTranstype, outDir);
  otRunning = false;
  if (r.error) {
    $('otLog').textContent += '\n[error] ' + r.error + '\n';
  } else if (r.code === 0) {
    $('otLog').textContent += '\n[done] Build succeeded.\n';
    toast('DITA-OT build succeeded.');
    window.api.showInFolder(outDir);
  } else {
    $('otLog').textContent += `\n[done] Build failed with exit code ${r.code}.\n`;
  }
};
$('btnOtCancel').onclick = () => { if (otRunning) window.api.ditaotCancel(); };
$('btnOtClose').onclick = () => $('dlgOtLog').close();

/* ---------------- boot ---------------- */

applySettings();
autosaveTick();

/* ================================================================
   v1.3 additions: pickers, quick open, shortcuts, status bar, restore
   ================================================================ */

/* generic list picker (returns a Promise) */
function pickFromList(title, items) {
  return new Promise(resolve => {
    $('pickTitle').textContent = title;
    const host = $('pickList');
    host.innerHTML = '';
    const done = v => { $('dlgPick').close(); resolve(v); };
    for (const it of items) {
      const d = document.createElement('div');
      d.className = 'pick-item';
      d.textContent = it.label;
      d.onclick = () => done(it.value);
      host.appendChild(d);
    }
    $('btnPickCancel').onclick = () => done(null);
    $('dlgPick').addEventListener('cancel', () => resolve(null), { once: true });
    $('dlgPick').showModal();
  });
}

/* quick open / command palette / link picker (one component, three modes) */
let qoMode = 'files';
let qoItems = [];
let qoSel = 0;

function allProjectFiles() {
  const out = [];
  (function walk(nodes) {
    for (const n of nodes) {
      if (n.dir) walk(n.children || []);
      else out.push(n.path);
    }
  })(S.tree || []);
  return out;
}

function buildCommands() {
  const hasFile = !!S.file;
  const cmds = [
    { label: 'File: New file…', run: () => { S.pendingInsert = null; openNewFileDialog(); }, when: !!S.root },
    { label: 'File: Open folder…', run: () => $('btnOpenFolder').click(), when: true },
    { label: 'File: Save', run: save, when: hasFile },
    { label: 'File: Close tab', run: () => closeTab(TABS.active), when: TABS.active >= 0 },
    { label: 'File: Reveal in File Explorer', run: () => window.api.showInFolder(S.file), when: hasFile },
    { label: 'File: Copy project-relative path', run: () => { navigator.clipboard.writeText(P.relative(S.root, S.file).split(P.sep).join('/')); toast('Copied.'); }, when: hasFile },
    { label: 'Export: HTML', run: () => $('btnExportHTML').click(), when: hasFile },
    { label: 'Export: PDF', run: () => $('btnExportPDF').click(), when: hasFile },
    { label: 'Publish: DITA-OT build…', run: () => $('btnPublishOT').click(), when: hasFile },
    { label: 'Export: Documentation site…', run: () => $('btnWebHelp').click(), when: hasFile },
    { label: 'DITA: Set open map as root map', run: () => $('btnRootMap').click(), when: hasFile && isMap(S.file) },
    { label: 'DITA: Rebuild dependency index', run: async () => { await buildDepIndex(); renderDeps(); updateBacklinks(); }, when: !!S.root },
    { label: 'View: Preview', run: () => setRightMode('preview'), when: true },
    { label: 'View: Map', run: () => setRightMode('map'), when: true },
    { label: 'View: Dependencies', run: () => setRightMode('deps'), when: true },
    { label: 'View: Problems', run: () => setRightMode('problems'), when: true },
    { label: 'View: Outline', run: () => setRightMode('outline'), when: true },
    { label: 'View: Find in files', run: () => setRightMode('search'), when: true },
    { label: 'View: AI assistant', run: () => setRightMode('assist'), when: true },
    { label: 'View: Toggle sidebar', run: toggleSidebar, when: true },
    { label: 'View: Toggle preview theme (light/dark)', run: () => $('btnPreviewTheme').click(), when: true },
    { label: 'Editor: Toggle word wrap', run: () => { SETTINGS.wordWrap = !SETTINGS.wordWrap; saveSettings(); applySettings(); toast('Word wrap ' + (SETTINGS.wordWrap ? 'on' : 'off')); }, when: true },
    { label: 'Versions: Show autosaved versions', run: () => $('btnVersions').click(), when: hasFile },
    { label: 'AI: Open assistant', run: () => setRightMode('ai'), when: true },
    { label: 'Help: How to use DITA Studio', run: () => openDocDialog(window.DOCS.GUIDE), when: true },
    { label: "Help: What's new", run: () => openDocDialog(window.DOCS.CHANGELOG), when: true },
    { label: 'Settings: Open settings', run: () => $('btnSettings').click(), when: true }
  ];
  return cmds.filter(c => c.when);
}

function openQuickOpen(mode) {
  qoMode = mode || 'files';
  if (qoMode !== 'commands' && !S.root) { toast('Open a folder first.'); return; }
  if (qoMode === 'link' && !S.file) { toast('Open a file to insert a link into.'); return; }
  if (qoMode === 'files' || qoMode === 'link') {
    const rel = p => P.relative(S.root, p).split(P.sep).join('/');
    qoItems = allProjectFiles().map(p => ({ label: rel(p), value: p }));
  } else {
    qoItems = buildCommands().map(c => ({ label: c.label, run: c.run }));
  }
  $('qoInput').value = '';
  $('qoInput').placeholder =
    qoMode === 'files' ? 'Type to filter project files… (Enter to open)' :
    qoMode === 'link' ? 'Pick a file to link to… (Enter to insert xref/link)' :
    'Type a command… (Enter to run)';
  renderQuickOpen('');
  $('dlgQuickOpen').showModal();
  $('qoInput').focus();
}

function qoChoose(item) {
  $('dlgQuickOpen').close();
  if (qoMode === 'files') openFile(item.value);
  else if (qoMode === 'link') insertLinkTo(item.value);
  else if (item.run) item.run();
}

function renderQuickOpen(q) {
  const host = $('qoList');
  host.innerHTML = '';
  const needle = q.toLowerCase();
  const scored = [];
  for (const x of qoItems) {
    const l = x.label.toLowerCase();
    if (needle && !l.includes(needle)) continue;
    const base = l.split('/').pop();
    const score = !needle ? 0 : base.startsWith(needle) ? 0 : base.includes(needle) ? 1 : l.indexOf(needle) + 2;
    scored.push({ x, score, depth: (x.label.match(/\//g) || []).length });
  }
  scored.sort((a, b) => a.score - b.score || a.depth - b.depth || a.x.label.length - b.x.label.length);
  const matches = scored.map(s2 => s2.x).slice(0, 40);
  qoSel = 0;
  matches.forEach((m, i) => {
    const d = document.createElement('div');
    d.className = 'pick-item' + (i === 0 ? ' sel' : '');
    d.textContent = m.label;
    d._item = m;
    d.onclick = () => qoChoose(m);
    host.appendChild(d);
  });
  if (!matches.length) host.innerHTML = '<div class="dep-none">No matches.</div>';
}

$('qoInput').addEventListener('input', () => renderQuickOpen($('qoInput').value));
$('qoInput').addEventListener('keydown', e => {
  const items = Array.from($('qoList').querySelectorAll('.pick-item'));
  if (!items.length) return;
  if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
    e.preventDefault();
    items[qoSel] && items[qoSel].classList.remove('sel');
    qoSel = e.key === 'ArrowDown' ? Math.min(qoSel + 1, items.length - 1) : Math.max(qoSel - 1, 0);
    items[qoSel].classList.add('sel');
    items[qoSel].scrollIntoView({ block: 'nearest' });
  } else if (e.key === 'Enter') {
    e.preventDefault();
    if (items[qoSel]) qoChoose(items[qoSel]._item);
  }
});

/* insert an xref (DITA) or markdown link to the chosen file */
function insertLinkTo(target) {
  const rel = P.relative(P.dirname(S.file), target).split(P.sep).join('/');
  const ext = extOf(target);
  if (isDita(S.file)) {
    const fmt = ['.md', '.mdx', '.markdown'].includes(ext) ? ' format="markdown"' : '';
    insertAtCaret(`<xref href="${rel}"${fmt}></xref>`);
  } else {
    insertAtCaret(`[${P.basename(target, ext)}](${rel})`);
  }
}

function toggleSidebar() { $('sidebar').classList.toggle('collapsed'); }

/* global shortcuts */
document.addEventListener('keydown', e => {
  const mod = e.ctrlKey || e.metaKey;
  if (!mod) return;
  const k = e.key.toLowerCase();
  if (k === 'p' && !e.shiftKey) { e.preventDefault(); openQuickOpen('files'); }
  else if (k === 'p' && e.shiftKey) { e.preventDefault(); openQuickOpen('commands'); }
  else if (k === 'n' && !e.shiftKey) { e.preventDefault(); if (!$('btnNewFile').disabled) { S.pendingInsert = null; openNewFileDialog(); } }
  else if (k === 'f' && e.shiftKey) { e.preventDefault(); setRightMode('search'); }
  else if (k === 'b' && !e.shiftKey) { e.preventDefault(); toggleSidebar(); }
});
/* the same bindings inside the editor (Monaco captures keys when focused) */
monacoEd.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyP, () => openQuickOpen('files'));
monacoEd.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyMod.Shift | monaco.KeyCode.KeyP, () => openQuickOpen('commands'));
monacoEd.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyK, () => openQuickOpen('link'));
monacoEd.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyB, toggleSidebar);

/* status bar */
function updateStatusBar() {
  if (!S.file || !activeModel()) { $('stPos').textContent = ''; $('stCount').textContent = ''; $('stType').textContent = ''; return; }
  const pos = monacoEd.getPosition() || { lineNumber: 1, column: 1 };
  const text = activeModel().getValue();
  const words = (text.match(/[\u4e00-\u9fff]|[A-Za-z0-9_]+/g) || []).length;
  $('stPos').textContent = `Ln ${pos.lineNumber}, Col ${pos.column}`;
  $('stCount').textContent = `${words} words · ${text.length} chars`;
  const e = extOf(S.file);
  $('stType').textContent = isMap(S.file) ? 'DITA map' : e === '.dita' ? 'DITA' : e === '.mdx' ? 'MDX' : (e === '.md' || e === '.markdown') ? 'Markdown' : e.replace('.', '').toUpperCase();
}
monacoEd.onDidChangeCursorPosition(updateStatusBar);
monacoEd.onDidChangeModelContent(updateStatusBar);

/* restore last project on startup */
(async function restoreLastProject() {
  const last = localStorage.getItem('ds:lastRoot');
  if (!last) return;
  try {
    if (!(await window.api.exists(last))) return;
    const r = await window.api.refreshTree(last);
    await loadProject(r.root, r.tree);
    // reopen the tabs from the previous session
    let prefs = {};
    try { prefs = JSON.parse(localStorage.getItem('ds:' + last) || '{}'); } catch (e) { /* ignore */ }
    const tabs = (prefs.openTabs || []).slice(0, 10);
    for (const p of tabs) {
      if (await window.api.exists(p)) await openFile(p);
    }
    if (TABS.list.length && Number.isInteger(prefs.activeTab) &&
        prefs.activeTab >= 0 && prefs.activeTab < TABS.list.length) {
      activateTab(prefs.activeTab);
    }
    toast('Reopened ' + last);
  } catch (e) { /* stay on empty state */ }
})();

/* ================================================================
   v1.5 additions: welcome/recents, backlinks, completions, scroll sync
   ================================================================ */

/* ---------------- welcome screen + recent projects ---------------- */

function recordRecentProject(root) {
  try {
    let list = JSON.parse(localStorage.getItem('ds:recentRoots') || '[]');
    list = [root, ...list.filter(r => r !== root)].slice(0, 6);
    localStorage.setItem('ds:recentRoots', JSON.stringify(list));
  } catch (e) { /* ignore */ }
}

async function openProjectPath(root) {
  if (!(await window.api.exists(root))) { toast('Folder no longer exists: ' + root); renderWelcome(); return; }
  const r = await window.api.refreshTree(root);
  await loadProject(r.root, r.tree);
}

function renderWelcome() {
  const host = $('recentList');
  let list = [];
  try { list = JSON.parse(localStorage.getItem('ds:recentRoots') || '[]'); } catch (e) { /* ignore */ }
  host.innerHTML = list.length ? '' : '<div class="dim">None yet.</div>';
  for (const r of list) {
    const d = document.createElement('div');
    d.className = 'recent-item';
    d.textContent = r;
    d.title = r;
    d.onclick = () => openProjectPath(r);
    host.appendChild(d);
  }
}
$('wOpenFolder').onclick = () => $('btnOpenFolder').click();
$('wNewFile').onclick = () => { S.pendingInsert = null; openNewFileDialog(); };
renderWelcome();

/* ---------------- backlinks chip (Obsidian-style) ---------------- */

function updateBacklinks() {
  const chip = $('stBacklinks');
  if (!S.file || !S.depIndex) { chip.hidden = true; return; }
  const rev = S.depIndex.reverse.get(P.resolve(S.file)) || [];
  chip.textContent = `↩ ${rev.length} backlink${rev.length === 1 ? '' : 's'}`;
  chip.hidden = false;
}
$('stBacklinks').onclick = () => setRightMode('deps');

/* ---------------- content completion (Oxygen/Notion-style) ---------------- */

const DITA_SNIPPETS = [
  { label: 'note', doc: 'Note admonition', text: '<note type="${1|note,tip,important,warning,caution|}">${2}</note>' },
  { label: 'codeblock', doc: 'Code block', text: '<codeblock>${1}</codeblock>' },
  { label: 'steps', doc: 'Task steps', text: '<steps>\n  <step><cmd>${1}</cmd></step>\n  <step><cmd>${2}</cmd></step>\n</steps>' },
  { label: 'simpletable', doc: '2-column simple table', text: '<simpletable>\n  <sthead>\n    <stentry>${1:Header}</stentry>\n    <stentry>${2:Header}</stentry>\n  </sthead>\n  <strow>\n    <stentry>${3}</stentry>\n    <stentry>${4}</stentry>\n  </strow>\n</simpletable>' },
  { label: 'xref', doc: 'Cross reference', text: '<xref href="${1}">${2}</xref>' },
  { label: 'image', doc: 'Image with alt', text: '<image href="${1}"><alt>${2}</alt></image>' },
  { label: 'section', doc: 'Titled section', text: '<section>\n  <title>${1}</title>\n  <p>${2}</p>\n</section>' },
  { label: 'ul', doc: 'Unordered list', text: '<ul>\n  <li>${1}</li>\n  <li>${2}</li>\n</ul>' },
  { label: 'dl', doc: 'Definition list', text: '<dl>\n  <dlentry>\n    <dt>${1}</dt>\n    <dd>${2}</dd>\n  </dlentry>\n</dl>' },
  { label: 'fig', doc: 'Figure with title', text: '<fig>\n  <title>${1}</title>\n  <image href="${2}"/>\n</fig>' },
  { label: 'prereq', doc: 'Task prerequisites', text: '<prereq>\n  <p>${1}</p>\n</prereq>' },
  { label: 'topicref', doc: 'Map topic reference', text: '<topicref href="${1}"/>' }
];

const DITA_ELEMENTS = ('p b i u ph codeph uicontrol filepath userinput systemoutput menucascade wintitle keyword term cite q ' +
  'title shortdesc section example note ul ol li sl sli dl dlentry dt dd codeblock pre lq fig image xref link table tgroup thead tbody row entry ' +
  'simpletable sthead strow stentry steps step cmd info stepresult substeps choices choice prereq context result postreq ' +
  'topicref chapter appendix mapref keydef topicmeta navtitle glossterm glossdef properties property proptype propvalue propdesc').split(' ');

const MD_SNIPPETS = [
  { label: 'code', doc: 'Fenced code block', text: '```${1:bash}\n${2}\n```' },
  { label: 'table', doc: 'Table', text: '| ${1:Column} | ${2:Column} |\n| --- | --- |\n| ${3} | ${4} |' },
  { label: 'link', doc: 'Link', text: '[${1:text}](${2:url})' },
  { label: 'image', doc: 'Image', text: '![${1:alt}](${2:path})' },
  { label: 'note', doc: 'Blockquote note', text: '> **Note:** ${1}' },
  { label: 'h2', doc: 'Heading 2', text: '## ${1}' },
  { label: 'h3', doc: 'Heading 3', text: '### ${1}' },
  { label: 'frontmatter', doc: 'YAML front matter', text: '---\ntitle: ${1}\n---\n' }
];

function snippetItems(snips, range) {
  return snips.map(s => ({
    label: '/' + s.label,
    kind: monaco.languages.CompletionItemKind.Snippet,
    documentation: s.doc,
    insertText: s.text,
    insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
    range
  }));
}

/* '/' at line start -> block insert menu (Notion-style) */
monaco.languages.registerCompletionItemProvider('xml', {
  triggerCharacters: ['/', '<', '"'],
  provideCompletionItems(model, position) {
    if (!S.file || !isDita(S.file)) return { suggestions: [] };
    const line = model.getLineContent(position.lineNumber).slice(0, position.column - 1);

    // slash menu: line is only whitespace + '/'
    if (/^\s*\/$/.test(line)) {
      const range = new monaco.Range(position.lineNumber, position.column - 1, position.lineNumber, position.column);
      return { suggestions: snippetItems(DITA_SNIPPETS, range) };
    }
    // element completion after '<'
    const em = line.match(/<([A-Za-z][\w.-]*)?$/);
    if (em && !line.endsWith('</')) {
      const typed = em[1] || '';
      const start = position.column - typed.length;
      const range = new monaco.Range(position.lineNumber, start, position.lineNumber, position.column);
      return {
        suggestions: DITA_ELEMENTS.map(el => ({
          label: el,
          kind: monaco.languages.CompletionItemKind.Property,
          insertText: el,
          range
        }))
      };
    }
    // keyref value completion from the key space
    if (/(keyref|conkeyref)="[\w./-]*$/.test(line) && S.keyspace) {
      const vm = line.match(/"([\w./-]*)$/);
      const typed = vm ? vm[1] : '';
      const start = position.column - typed.length;
      const range = new monaco.Range(position.lineNumber, start, position.lineNumber, position.column);
      return {
        suggestions: Object.keys(S.keyspace).map(k => ({
          label: k,
          kind: monaco.languages.CompletionItemKind.Reference,
          detail: S.keyspace[k].text || S.keyspace[k].hrefRaw || '',
          insertText: k,
          range
        }))
      };
    }
    return { suggestions: [] };
  }
});

monaco.languages.registerCompletionItemProvider('markdown', {
  triggerCharacters: ['/'],
  provideCompletionItems(model, position) {
    const line = model.getLineContent(position.lineNumber).slice(0, position.column - 1);
    if (!/^\s*\/$/.test(line)) return { suggestions: [] };
    const range = new monaco.Range(position.lineNumber, position.column - 1, position.lineNumber, position.column);
    return { suggestions: snippetItems(MD_SNIPPETS, range) };
  }
});

/* ---------------- editor <-> preview scroll sync (Typora-style) ---------------- */

let syncingScroll = false;
let lastScrollSync = 0;
monacoEd.onDidScrollChange(e => {
  if (syncingScroll || !S.file || $('previewPane').hidden) return;
  const now = Date.now();
  if (now - lastScrollSync < 60) return;
  lastScrollSync = now;
  const frame = $('previewFrame');
  const doc = frame.contentDocument;
  if (!doc || !doc.documentElement) return;
  const editorMax = monacoEd.getScrollHeight() - monacoEd.getLayoutInfo().height;
  if (editorMax <= 0) return;
  const ratio = Math.min(1, Math.max(0, e.scrollTop / editorMax));
  const target = (doc.documentElement.scrollHeight - doc.documentElement.clientHeight) * ratio;
  syncingScroll = true;
  doc.documentElement.scrollTop = target;
  requestAnimationFrame(() => { syncingScroll = false; });
});

/* ================================================================
   v1.6: responsive WebHelp export
   ================================================================ */

/* posix-style relative link between two output-relative paths */
function whRelLink(fromRel, toRel) {
  const from = fromRel.split('/').slice(0, -1);
  const to = toRel.split('/');
  let i = 0;
  while (i < from.length && i < to.length - 1 && from[i] === to[i]) i++;
  return '../'.repeat(from.length - i) + to.slice(i).join('/') || './';
}

function whSanitize(rel) {
  return rel.split('/').map(seg => seg === '..' ? '__up' : seg.replace(/[^\w.\-]/g, '_')).join('/');
}

function whOutRel(srcAbs) {
  let rel = P.relative(S.root, srcAbs).split(P.sep).join('/');
  if (rel.startsWith('..')) rel = P.basename(srcAbs);
  const ext = extOf(srcAbs);
  return 'topics/' + whSanitize(rel.slice(0, rel.length - ext.length) + '.html');
}

async function whTitleOf(srcAbs, content) {
  try {
    const c = content !== undefined ? content : await readCached(srcAbs);
    if (isDita(srcAbs)) {
      const doc = new DOMParser().parseFromString(c, 'application/xml');
      if (!doc.querySelector('parsererror')) {
        const t = doc.querySelector('mainbooktitle, glossterm') || doc.querySelector('title');
        if (t && t.textContent.trim()) return t.textContent.trim();
      }
    } else {
      const fm = c.match(/^---\r?\n[\s\S]*?^title:\s*(.+)$[\s\S]*?\r?\n---/m);
      if (fm) return fm[1].trim();
      const h = c.match(/^#\s+(.+)$/m);
      if (h) return h[1].trim();
    }
  } catch (e) { /* fall through */ }
  return P.basename(srcAbs, extOf(srcAbs));
}

const WH_CONTENT_EXT = ['.dita', '.xml', '.md', '.mdx', '.markdown'];

async function whNavFromMap(mapPath, content, depth, visited) {
  depth = depth || 0;
  visited = visited || new Set();
  const abs = P.resolve(mapPath);
  if (visited.has(abs) || depth > 3) return { title: P.basename(mapPath), children: [] };
  visited.add(abs);
  const doc = new DOMParser().parseFromString(content, 'application/xml');
  if (doc.querySelector('parsererror')) throw new Error('Map XML does not parse: ' + P.basename(mapPath));
  const titleEl = doc.querySelector('booktitle > mainbooktitle') || doc.querySelector('map > title, bookmap > title');
  const mapDir = P.dirname(abs);

  async function walk(el) {
    const out = [];
    for (const ch of Array.from(el.children)) {
      if (!REF_TAGS.has(ch.tagName)) { continue; }
      if (ch.tagName === 'keydef' || ch.getAttribute('processing-role') === 'resource-only') continue;
      const href = ch.getAttribute('href');
      const nav = ch.getAttribute('navtitle') ||
        ((ch.querySelector(':scope > topicmeta > navtitle') || {}).textContent || '').trim();
      if (href && !/^([a-z]+:)?\/\//i.test(href)) {
        const clean = href.split('#')[0];
        const tAbs = P.resolve(P.join(mapDir, clean));
        const ext = P.extname(clean).toLowerCase();
        if (ext === '.ditamap' || ext === '.bookmap') {
          try {
            const sub = await whNavFromMap(tAbs, await readCached(tAbs), depth + 1, visited);
            out.push({ src: null, title: nav || sub.title, children: sub.children.concat(await walk(ch)) });
          } catch (e) { /* skip broken submap */ }
          continue;
        }
        if (WH_CONTENT_EXT.includes(ext)) {
          out.push({ src: tAbs, title: nav || await whTitleOf(tAbs), children: await walk(ch) });
          continue;
        }
      }
      // topichead / topicgroup / container without local content
      const kids = await walk(ch);
      if (nav || kids.length) out.push({ src: null, title: nav || ch.tagName, children: kids });
    }
    return out;
  }

  return {
    title: (titleEl && titleEl.textContent.trim()) || P.basename(mapPath, extOf(mapPath)),
    children: await walk(doc.documentElement)
  };
}

function whFlatten(nodes, arr, trail) {
  trail = trail || [];
  for (const n of nodes) {
    n.trail = trail;
    if (n.src) arr.push(n);
    whFlatten(n.children, arr, trail.concat([n.title]));
  }
}

/* rewrite intra-site links + collect image assets */
function whProcess(bodyHtml, pg, srcToOut, assets) {
  const tpl = document.createElement('template');
  tpl.innerHTML = bodyHtml;
  const pageRel = srcToOut.get(pg.src);
  const srcDir = P.dirname(pg.src);

  tpl.content.querySelectorAll('img[src], video[src], audio[src], source[src]').forEach(node => {
    const src = node.getAttribute('src');
    if (!src || /^([a-z]+:)?\/\//i.test(src) || src.startsWith('data:')) return;
    const abs = P.resolve(P.join(srcDir, src));
    let rel = P.relative(S.root, abs).split(P.sep).join('/');
    if (rel.startsWith('..')) rel = P.basename(abs);
    const assetRel = 'media/' + whSanitize(rel);
    assets.set(abs, assetRel);
    node.setAttribute('src', whRelLink(pageRel, assetRel));
  });

  tpl.content.querySelectorAll('a[href]').forEach(a => {
    const href = a.getAttribute('href');
    if (!href || /^([a-z]+:)?\/\//i.test(href) || href.startsWith('#') || /^(mailto|tel):/i.test(href)) return;
    const [pathPart, frag] = href.split('#');
    if (!pathPart) return;
    const abs = P.resolve(P.join(srcDir, pathPart));
    if (srcToOut.has(abs)) {
      a.setAttribute('href', whRelLink(pageRel, srcToOut.get(abs)) + (frag ? '#' + frag : ''));
    }
  });

  return tpl.innerHTML;
}

function whText(bodyHtml) {
  const tpl = document.createElement('template');
  tpl.innerHTML = bodyHtml;
  return (tpl.content.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 4000);
}

function whTocHtml(nodes, pageRel, currentSrc, trailSet) {
  let out = '<ul>';
  for (const n of nodes) {
    const isCurrent = n.src === currentSrc;
    const onTrail = trailSet.has(n);
    const label = n.src
      ? `<a class="${isCurrent ? 'current' : ''}" href="${whRelLink(pageRel, whOutRelCached(n.src))}">${escHtml(n.title)}</a>`
      : `<span class="toc-head">${escHtml(n.title)}</span>`;
    if (n.children.length) {
      out += `<li><details${(onTrail || isCurrent) ? ' open' : ''}><summary>${label}</summary>${whTocHtml(n.children, pageRel, currentSrc, trailSet)}</details></li>`;
    } else {
      out += `<li>${label}</li>`;
    }
  }
  return out + '</ul>';
}

let _whOutCache = null;
function whOutRelCached(src) {
  if (!_whOutCache.has(src)) _whOutCache.set(src, whOutRel(src));
  return _whOutCache.get(src);
}

function whAncestorsOf(nodes, targetSrc, acc, path) {
  for (const n of nodes) {
    const newPath = path.concat([n]);
    if (n.src === targetSrc) { newPath.forEach(x => acc.add(x)); return true; }
    if (whAncestorsOf(n.children, targetSrc, acc, newPath)) return true;
  }
  return false;
}

function whPage(site, pg, body, srcToOut, pages, idx, opts) {
  const pageRel = srcToOut.get(pg.src);
  const asset = rel => whRelLink(pageRel, rel);
  const trailSet = new Set();
  whAncestorsOf(site.children, pg.src, trailSet, []);
  const crumbs = pg.trail.map(t => `<span>${escHtml(t)}</span>`).join('<span class="sep">›</span>');
  const prev = idx > 0 ? pages[idx - 1] : null;
  const next = idx < pages.length - 1 ? pages[idx + 1] : null;
  const navLink = (p, cls, label) => p
    ? `<a class="pager ${cls}" href="${whRelLink(pageRel, srcToOut.get(p.src))}">${label}<b>${escHtml(p.title)}</b></a>`
    : '<span></span>';
  return `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escHtml(pg.title)} — ${escHtml(site.title)}</title>
<link rel="stylesheet" href="${asset('assets/webhelp.css')}">
</head><body>
<header class="wh-header">
  <button id="whMenu" class="wh-burger" aria-label="Toggle navigation">☰</button>
  <a class="wh-site" href="${asset('index.html')}">${escHtml(site.title)}</a>
  <div class="wh-search"><input id="whSearch" placeholder="Search…" autocomplete="off"><div id="whResults" hidden></div></div>
  ${opts && opts.pdf ? `<a class="wh-pdf" href="${asset('assets/' + opts.pdfName)}" download title="Download the whole publication as PDF">PDF</a>` : ''}
  <button id="whTheme" class="wh-theme" aria-label="Toggle theme">☾</button>
</header>
<div class="wh-layout">
  <nav class="wh-nav" id="whNav">${whTocHtml(site.children, pageRel, pg.src, trailSet)}</nav>
  <main class="wh-main">
    <div class="wh-crumbs">${crumbs}${crumbs ? '<span class="sep">›</span>' : ''}<span class="here">${escHtml(pg.title)}</span></div>
    <article class="wh-article">${body}</article>
    <div class="wh-pager">${navLink(prev, 'prev', '← Previous<br>')}${navLink(next, 'next', 'Next →<br>')}</div>
  </main>
</div>
<script>window.WH_BASE=${JSON.stringify(whRelLink(pageRel, 'index.html').replace(/\/?index\.html$/, '') || '.')};</script>
<script src="${asset('assets/search-index.js')}"></script>
<script src="${asset('assets/webhelp.js')}"></script>
</body></html>`;
}

function whLanding(site, srcToOut, pages, opts) {
  const first = pages[0];
  const fp = (opts && opts.front) || {};
  const pieces = [];
  if (fp.hero !== false) {
    pieces.push(`<h1>${escHtml(site.title)}</h1>`);
    if (fp.tagline) pieces.push(`<p class="wh-tagline">${escHtml(fp.tagline)}</p>`);
  }
  if (fp.start !== false && first) {
    pieces.push(`<p><a class="wh-start" href="${srcToOut.get(first.src)}">Start reading →</a></p>`);
  }
  if (fp.cards !== false && site.children.length > 1) {
    const cards = site.children.map(n => {
      const flat = [];
      whFlatten([n], flat);
      const target = flat[0] ? srcToOut.get(flat[0].src) : null;
      const count = flat.length;
      const inner = `<b>${escHtml(n.title)}</b><span>${count} topic${count === 1 ? '' : 's'}</span>`;
      return target ? `<a class="wh-card" href="${target}">${inner}</a>` : `<div class="wh-card">${inner}</div>`;
    }).join('');
    pieces.push(`<div class="wh-cards">${cards}</div>`);
  }
  if (fp.toc !== false) {
    pieces.push(`<nav class="wh-nav wh-nav-landing">${whTocHtml(site.children, 'index.html', null, new Set())}</nav>`);
  }
  if (fp.footer) pieces.push(`<footer class="wh-footer">${escHtml(fp.footer)}</footer>`);

  return `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escHtml(site.title)}</title>
<link rel="stylesheet" href="assets/webhelp.css">
</head><body>
<header class="wh-header">
  <span class="wh-site">${escHtml(site.title)}</span>
  ${fp.search !== false ? '<div class="wh-search"><input id="whSearch" placeholder="Search…" autocomplete="off"><div id="whResults" hidden></div></div>' : ''}
  ${opts && opts.pdf ? `<a class="wh-pdf" href="assets/${opts.pdfName}" download title="Download the whole publication as PDF">PDF</a>` : ''}
  <button id="whTheme" class="wh-theme" aria-label="Toggle theme">☾</button>
</header>
<main class="wh-landing">
${pieces.join('\n')}
</main>
<script>window.WH_BASE='.';</script>
<script src="assets/search-index.js"></script>
<script src="assets/webhelp.js"></script>
</body></html>`;
}

const WH_CSS = `:root{--bg:#fff;--fg:#1f2933;--sub:#52606d;--line:#e1e5ea;--code:#f2f4f7;--accent:#e0a458;--link:#1a6baa;--nav:#f7f8fa}
[data-theme=dark]{--bg:#171b21;--fg:#d7dde4;--sub:#9aa5b1;--line:#2a323c;--code:#232b34;--link:#6cb2e0;--nav:#1c2229}
*{box-sizing:border-box}html,body{margin:0}
body{background:var(--bg);color:var(--fg);font-family:"Segoe UI",system-ui,sans-serif;line-height:1.6;font-size:15.5px}
.wh-header{position:sticky;top:0;z-index:20;display:flex;align-items:center;gap:14px;padding:10px 18px;background:var(--bg);border-bottom:1px solid var(--line)}
.wh-site{font-weight:600;color:var(--fg);text-decoration:none;white-space:nowrap}
.wh-burger{display:none;background:none;border:1px solid var(--line);border-radius:5px;color:var(--fg);font-size:15px;padding:3px 9px;cursor:pointer}
.wh-theme{background:none;border:1px solid var(--line);border-radius:5px;color:var(--fg);padding:3px 10px;cursor:pointer}
.wh-pdf{margin-left:auto;color:var(--link);border:1px solid var(--line);border-radius:5px;padding:4px 12px;text-decoration:none;font-size:13px;font-weight:600}
.wh-pdf:hover{border-color:var(--accent)}
.wh-pdf+.wh-theme{margin-left:0}
.wh-facets{padding:9px 12px;border-bottom:1px solid var(--line);background:var(--code)}
.wh-fgroup{display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin:3px 0}
.wh-fgroup b{font-size:11px;color:var(--sub);text-transform:uppercase;letter-spacing:.06em;margin-right:2px}
.wh-chip{background:var(--bg);border:1px solid var(--line);border-radius:20px;color:var(--fg);font-size:12px;padding:2px 10px;cursor:pointer}
.wh-chip i{font-style:normal;color:var(--sub);font-size:11px}
.wh-chip.on{border-color:var(--accent);color:var(--accent)}
.wh-none{padding:12px;color:var(--sub)}
#whResults em{display:block;color:var(--sub);font-size:11px;font-style:normal;margin:1px 0}
.wh-search{position:relative;flex:1;max-width:420px}
.wh-search input{width:100%;padding:7px 12px;border:1px solid var(--line);border-radius:6px;background:var(--code);color:var(--fg);font-size:13.5px}
#whResults{position:absolute;top:110%;left:0;right:0;background:var(--bg);border:1px solid var(--line);border-radius:6px;max-height:340px;overflow:auto;box-shadow:0 10px 30px rgba(0,0,0,.18)}
#whResults a{display:block;padding:9px 12px;color:var(--fg);text-decoration:none;border-bottom:1px solid var(--line)}
#whResults a:hover{background:var(--code)}#whResults b{color:var(--link);display:block;font-size:13.5px}
#whResults span{color:var(--sub);font-size:12px}
.wh-layout{display:grid;grid-template-columns:290px 1fr;min-height:calc(100vh - 55px)}
.wh-nav{background:var(--nav);border-right:1px solid var(--line);padding:16px 10px;overflow:auto;position:sticky;top:55px;height:calc(100vh - 55px);font-size:13.8px}
.wh-nav ul{list-style:none;margin:0;padding-left:14px}.wh-nav>ul{padding-left:4px}
.wh-nav li{margin:1px 0}
.wh-nav a{color:var(--fg);text-decoration:none;display:block;padding:4px 8px;border-radius:5px}
.wh-nav a:hover{background:var(--code)}
.wh-nav a.current{background:var(--code);color:var(--link);font-weight:600;border-left:3px solid var(--accent);padding-left:5px}
.wh-nav summary{cursor:pointer;padding:2px 0;color:var(--sub)}
.wh-nav summary a,.wh-nav summary .toc-head{display:inline-block;color:var(--fg)}
.toc-head{padding:4px 8px;color:var(--sub);font-weight:600}
.wh-main{padding:26px 40px;max-width:900px;min-width:0}
.wh-crumbs{font-size:12.5px;color:var(--sub);margin-bottom:14px}.wh-crumbs .sep{margin:0 7px}.wh-crumbs .here{color:var(--fg)}
.wh-article h1{font-size:1.7em;border-bottom:2px solid var(--accent);padding-bottom:.25em}
.wh-article h2{font-size:1.3em;margin-top:1.6em}.wh-article h3{font-size:1.1em}
.wh-article img{max-width:100%}
.wh-article pre,.wh-article .d-code{background:var(--code);border:1px solid var(--line);border-radius:6px;padding:10px 12px;overflow:auto;font-family:Consolas,monospace;font-size:.9em}
.wh-article code,.wh-article kbd,.wh-article samp{background:var(--code);border-radius:3px;padding:1px 4px;font-family:Consolas,monospace;font-size:.92em}
.wh-article a{color:var(--link)}
.wh-article table,.wh-article table.d-table{border-collapse:collapse;width:100%;margin:12px 0}
.wh-article th,.wh-article td{border:1px solid var(--line);padding:6px 10px;text-align:left;vertical-align:top}
.wh-article th{background:var(--code)}
.wh-article .d-note{border-left:4px solid #7fb3d5;background:var(--code);padding:8px 12px;margin:12px 0;border-radius:0 5px 5px 0}
.wh-article .d-note-warning,.wh-article .d-note-caution,.wh-article .d-note-danger{border-left-color:#d97b6c}
.wh-article .d-note-important,.wh-article .d-note-attention{border-left-color:var(--accent)}
.wh-article .d-label{font-weight:600;font-size:.82em;letter-spacing:.08em;text-transform:uppercase;color:#b07a24;margin-bottom:2px}
.wh-article .d-block{margin:14px 0}.wh-article .shortdesc{color:var(--sub);font-size:1.02em}
.wh-article .d-ui{background:var(--code);border:1px solid var(--line);border-radius:3px;padding:0 5px;font-weight:600;font-size:.92em}
.wh-pager{display:flex;justify-content:space-between;gap:16px;margin-top:44px;border-top:1px solid var(--line);padding-top:18px}
.pager{color:var(--sub);text-decoration:none;font-size:12.5px;max-width:46%}
.pager b{color:var(--link);font-size:14px}.pager.next{text-align:right}
.wh-landing{max-width:760px;margin:0 auto;padding:48px 24px}
.wh-landing h1{border-bottom:2px solid var(--accent);padding-bottom:.3em}
.wh-start{display:inline-block;background:var(--accent);color:#1f2933;font-weight:600;text-decoration:none;padding:9px 22px;border-radius:7px}
.wh-nav-landing{position:static;height:auto;border:1px solid var(--line);border-radius:8px;margin-top:22px}
.wh-tagline{color:var(--sub);font-size:1.1em;margin-top:-8px}
.wh-cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:12px;margin:22px 0}
.wh-card{display:flex;flex-direction:column;gap:5px;border:1px solid var(--line);border-radius:9px;padding:15px 17px;text-decoration:none;color:var(--fg);background:var(--nav)}
.wh-card:hover{border-color:var(--accent)}
.wh-card b{font-size:14.5px}.wh-card span{color:var(--sub);font-size:12px}
.wh-footer{margin-top:44px;padding-top:16px;border-top:1px solid var(--line);color:var(--sub);font-size:12.5px}
.wh-article video,.wh-article audio{max-width:100%;border-radius:6px;margin:10px 0}
.wh-article .d-embed{position:relative;aspect-ratio:16/9;margin:14px 0}
.wh-article .d-embed iframe{position:absolute;inset:0;width:100%;height:100%;border:0;border-radius:8px}
@media (max-width:900px){
  .wh-burger{display:block}
  .wh-layout{grid-template-columns:1fr}
  .wh-nav{position:fixed;left:0;top:55px;bottom:0;width:290px;transform:translateX(-100%);transition:transform .2s;z-index:15;box-shadow:6px 0 24px rgba(0,0,0,.15)}
  body.nav-open .wh-nav{transform:none}
  .wh-main{padding:20px 18px}
}`;

const WH_JS = `(function(){
var t=localStorage.getItem('wh-theme');if(t)document.documentElement.setAttribute('data-theme',t);
var tb=document.getElementById('whTheme');
if(tb){tb.textContent=t==='dark'?'\u2600':'\u263E';
tb.onclick=function(){var cur=document.documentElement.getAttribute('data-theme')==='dark'?'':'dark';
if(cur)document.documentElement.setAttribute('data-theme',cur);else document.documentElement.removeAttribute('data-theme');
localStorage.setItem('wh-theme',cur);tb.textContent=cur==='dark'?'\u2600':'\u263E';};}
var mb=document.getElementById('whMenu');
if(mb)mb.onclick=function(){document.body.classList.toggle('nav-open');};

/* search with refine-by filters (type and section) */
var inp=document.getElementById('whSearch'),res=document.getElementById('whResults');
if(inp&&window.SEARCH_INDEX){
var selTy={},selSec={};
function chip(group,val,count,on){
return '<button class="wh-chip'+(on?' on':'')+'" data-g="'+group+'" data-v="'+encodeURIComponent(val)+'">'+val+' <i>'+count+'</i></button>';}
function counts(arr,key){var m={};arr.forEach(function(e){m[e[key]]=(m[e[key]]||0)+1;});return m;}
function active(sel){return Object.keys(sel).filter(function(k){return sel[k];});}
function render(){
var q=inp.value.trim().toLowerCase();
if(q.length<2){res.hidden=true;return;}
var textHits=window.SEARCH_INDEX.filter(function(e){
return e.t.toLowerCase().indexOf(q)>=0||e.x.toLowerCase().indexOf(q)>=0;});
var tys=active(selTy),secs=active(selSec);
var hits=textHits.filter(function(e){
return (!tys.length||selTy[e.ty])&&(!secs.length||selSec[e.sec]);});
var tyC=counts(textHits,'ty'),secC=counts(textHits,'sec');
var bar='';
var tyKeys=Object.keys(tyC),secKeys=Object.keys(secC);
if(textHits.length&&(tyKeys.length>1||secKeys.length>1||tys.length||secs.length)){
bar='<div class="wh-facets">';
if(tyKeys.length>1||tys.length)bar+='<div class="wh-fgroup"><b>Type</b>'+tyKeys.sort().map(function(k){return chip('ty',k,tyC[k],!!selTy[k]);}).join('')+'</div>';
if(secKeys.length>1||secs.length)bar+='<div class="wh-fgroup"><b>Section</b>'+secKeys.sort().map(function(k){return chip('sec',k,secC[k],!!selSec[k]);}).join('')+'</div>';
bar+='</div>';}
var list=hits.slice(0,20).map(function(e){
var i=e.x.toLowerCase().indexOf(q);var ctx=i>=0?e.x.slice(Math.max(0,i-40),i+60):e.x.slice(0,90);
return '<a href="'+window.WH_BASE+'/'+e.u+'"><b>'+e.t+'</b><em>'+e.ty+' \u00B7 '+e.sec+'</em><span>\u2026'+ctx+'\u2026</span></a>';
}).join('');
res.innerHTML=bar+(hits.length?list:'<div class="wh-none">No results'+(tys.length||secs.length?' with these filters':'')+'.</div>');
res.hidden=false;
res.querySelectorAll('.wh-chip').forEach(function(c){
c.onclick=function(ev){ev.stopPropagation();
var g=c.dataset.g,v=decodeURIComponent(c.dataset.v);
if(g==='ty')selTy[v]=!selTy[v];else selSec[v]=!selSec[v];
render();};});
}
inp.addEventListener('input',function(){selTy={};selSec={};render();});
inp.addEventListener('focus',render);
document.addEventListener('click',function(ev){if(!ev.target.closest('.wh-search'))res.hidden=true;});
}})();`;

/* site style packs, scoped to article content so the shell stays intact */
const WH_PACKS = {
  default: '',
  portal: `.wh-article h1{border-bottom:none;color:#0d5c8c;font-weight:650}
[data-theme=dark] .wh-article h1{color:#6cb2e0}
.wh-article h2{color:#0d5c8c;border-bottom:1px solid var(--line);padding-bottom:.2em}
[data-theme=dark] .wh-article h2{color:#6cb2e0}
.wh-article .d-note{border-radius:6px}.wh-article pre,.wh-article .d-code{border-radius:8px}`,
  print: `.wh-article{font-family:Georgia,"Times New Roman",serif;font-size:15px;line-height:1.7}
.wh-article h1,.wh-article h2,.wh-article h3{font-family:Georgia,serif;font-weight:700}
.wh-article .d-note{background:none;border:1px solid var(--sub);border-left-width:4px}`,
  compact: `.wh-article{font-size:13.5px;line-height:1.45}
.wh-article h1{font-size:1.4em}.wh-article h2{font-size:1.15em;margin-top:1.1em}.wh-article h3{font-size:1em}
.wh-article p{margin:.5em 0}.wh-article th,.wh-article td{padding:3px 7px}`,
  ledger: `:root{--accent:#1256a0;--link:#1256a0}
[data-theme=dark]{--accent:#5b9bd5;--link:#7db8ea}
.wh-article h1{color:var(--link);border-bottom-width:3px}
.wh-article h2{color:var(--link)}
.wh-article .d-note{border-left-color:var(--link)}`,
  handbook: `.wh-article{font-family:Georgia,"Times New Roman",serif;line-height:1.75}
.wh-article h1,.wh-article h2,.wh-article h3{font-family:Georgia,serif}
:root{--accent:#b9a06b}
.wh-article .shortdesc{font-style:italic}`,
  terminal: `.wh-article{font-family:Consolas,"Cascadia Code",monospace;font-size:13.5px}
:root{--accent:#2a9d63;--link:#1d7a4b}
[data-theme=dark]{--link:#4fc08d}
.wh-article h2::before{content:"## "}.wh-article h3::before{content:"### "}`
};

const WH_TYPE_LABEL = { task: 'Task', concept: 'Concept', reference: 'Reference', troubleshooting: 'Troubleshooting', glossentry: 'Glossary', topic: 'Topic' };
function whTypeOf(srcAbs, content) {
  if (isDita(srcAbs)) {
    const m = content.match(/<\s*(task|concept|reference|troubleshooting|glossentry|topic)[\s>]/);
    return m ? WH_TYPE_LABEL[m[1]] : 'Topic';
  }
  return 'Article';
}

/* absolute file:// image URLs for the combined PDF */
function whAbsolutize(bodyHtml, srcDir) {
  const tpl = document.createElement('template');
  tpl.innerHTML = bodyHtml;
  tpl.content.querySelectorAll('img[src]').forEach(img => {
    const src = img.getAttribute('src');
    if (!src || /^([a-z]+:)?\/\//i.test(src) || src.startsWith('data:')) return;
    img.setAttribute('src', fileUrl(P.resolve(P.join(srcDir, src))));
  });
  return tpl.innerHTML;
}

function openSiteDialog() {
  if (!S.file) return;
  $('siteStylePack').value = SETTINGS.stylePack || 'default';
  $('siteCustomCss').value = SETTINGS.customCss || '';
  const fp = SETTINGS.siteFront || {};
  $('fpHero').checked = fp.hero !== false;
  $('fpTagline').value = fp.tagline || '';
  $('fpSearch').checked = fp.search !== false;
  $('fpStart').checked = fp.start !== false;
  $('fpCards').checked = fp.cards !== false;
  $('fpToc').checked = fp.toc !== false;
  $('fpFooter').value = fp.footer || '';
  $('dlgSite').showModal();
}
$('btnSiteCancel').onclick = () => $('dlgSite').close();
$('btnSiteCss').onclick = async () => {
  const f = await window.api.pickFile('Choose a custom stylesheet for the site', [{ name: 'CSS', extensions: ['css'] }]);
  if (f) $('siteCustomCss').value = f;
};
$('btnSiteCssClear').onclick = () => { $('siteCustomCss').value = ''; };
$('btnSiteGo').onclick = async () => {
  const opts = {
    pack: $('siteStylePack').value,
    cssPath: $('siteCustomCss').value,
    pdf: $('sitePdf').checked,
    cover: $('siteCover').checked,
    front: {
      hero: $('fpHero').checked,
      tagline: $('fpTagline').value.trim(),
      search: $('fpSearch').checked,
      start: $('fpStart').checked,
      cards: $('fpCards').checked,
      toc: $('fpToc').checked,
      footer: $('fpFooter').value.trim()
    }
  };
  SETTINGS.siteFront = opts.front;
  saveSettings();
  $('dlgSite').close();
  await exportWebHelp(null, opts);
};

async function exportWebHelp(forcedOutDir, opts) {
  opts = opts || { pack: 'default', cssPath: '', pdf: false };
  if (!S.file) return;
  const outDir = forcedOutDir || await window.api.pickFolder('Choose an output folder for the WebHelp site (an empty folder is recommended)');
  if (!outDir) return;
  toast('Building the documentation site…');
  try {
    _whOutCache = new Map();
    let site;
    if (isMap(S.file)) {
      site = await whNavFromMap(S.file, editor.value);
    } else {
      const t = await whTitleOf(S.file, editor.value);
      site = { title: t, children: [{ src: P.resolve(S.file), title: t, children: [] }] };
    }
    const pages = [];
    whFlatten(site.children, pages);
    if (!pages.length) { toast('No publishable topics found in this map.'); return; }
    const srcToOut = new Map();
    for (const p of pages) srcToOut.set(p.src, whOutRelCached(p.src));

    let customCssText = '';
    if (opts.cssPath) {
      try { customCssText = await window.api.readFile(opts.cssPath); } catch (e) { customCssText = ''; }
    }
    opts.pdfName = whSanitize(site.title.replace(/\s+/g, '-').toLowerCase() || 'publication') + '.pdf';

    const assets = new Map();
    const searchIndex = [];
    const files = [];
    const pdfBodies = [];
    for (let i = 0; i < pages.length; i++) {
      const pg = pages[i];
      const content = (P.resolve(S.file) === pg.src) ? editor.value : await readCached(pg.src);
      let body = (await buildBodyHtml(pg.src, content)) || '';
      if (opts.pdf) pdfBodies.push(whAbsolutize(body, P.dirname(pg.src)));
      body = whProcess(body, pg, srcToOut, assets);
      searchIndex.push({
        t: pg.title,
        u: srcToOut.get(pg.src),
        x: whText(body),
        ty: whTypeOf(pg.src, content),
        sec: (pg.trail && pg.trail[0]) || 'Top level'
      });
      files.push({ rel: srcToOut.get(pg.src), content: whPage(site, pg, body, srcToOut, pages, i, opts) });
    }
    files.push({ rel: 'assets/webhelp.css', content: WH_CSS + '\n' + (WH_PACKS[opts.pack] || '') + '\n' + customCssText });
    files.push({ rel: 'assets/webhelp.js', content: WH_JS });
    files.push({ rel: 'assets/search-index.js', content: 'window.SEARCH_INDEX=' + JSON.stringify(searchIndex) + ';' });
    files.push({ rel: 'index.html', content: whLanding(site, srcToOut, pages, opts) });

    for (const f of files) {
      await window.api.writeFile(P.join(outDir, ...f.rel.split('/')), f.content);
    }
    let copied = 0;
    for (const [srcAbs, rel] of assets) {
      try { await window.api.copyFile(srcAbs, P.join(outDir, ...rel.split('/'))); copied++; } catch (e) { /* missing image */ }
    }
    if (opts.pdf) {
      toast('Rendering the publication PDF…');
      const cover = opts.cover
        ? `<div style="height:93vh;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;page-break-after:always"><div style="font-size:36px;font-weight:600;border-bottom:3px solid #e0a458;padding-bottom:16px">${escHtml(site.title)}</div><div style="margin-top:20px;color:#52606d;font-size:14px">${new Date().toISOString().slice(0, 10)}</div></div>`
        : '';
      const pdfToc = pages.length > 1
        ? `<nav class="doc-contents"><b>Contents</b><ol>${pages.map((p, i) => `<li><a href="#pdf-t${i}">${escHtml(p.title)}</a></li>`).join('')}</ol></nav>`
        : '';
      const pdfBody = cover + `<h1>${escHtml(site.title)}</h1>` + pdfToc +
        pdfBodies.map((b, i) => `<hr class="topic-sep"><div id="pdf-t${i}">` + b + '</div>').join('');
      const pdfHtml = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>${escHtml(site.title)}</title><style>${publishCss('light')}\n${(STYLE_PACKS[opts.pack] || '')}\n${customCssText}</style></head><body>${pdfBody}</body></html>`;
      await window.api.exportPDFFile(pdfHtml, P.join(outDir, 'assets', opts.pdfName));
    }
    toast(`Documentation site generated: ${pages.length} page(s), ${copied} media file(s)${opts.pdf ? ', PDF included' : ''}.`);
    window.api.showInFolder(P.join(outDir, 'index.html'));
  } catch (e) {
    toast('Site generation failed: ' + e.message);
  }
}
$('btnWebHelp').onclick = () => openSiteDialog();

/* ================================================================
   v1.8: menubar
   ================================================================ */

const APP_VERSION = '1.8.0';
let menubarOpen = null;

function ditavalMenuItems() {
  const files = [];
  (function walk(nodes) {
    for (const n of nodes) {
      if (n.dir) walk(n.children || []);
      else if (extOf(n.name) === '.ditaval') files.push(n.path);
    }
  })(S.tree || []);
  const pick = v => {
    $('ditavalSel').value = v;
    $('ditavalSel').dispatchEvent(new Event('change'));
  };
  const items = [{ label: 'No filter', checked: !S.ditaval, run: () => pick('') }];
  for (const f of files) {
    items.push({ label: P.relative(S.root, f), checked: S.ditaval === f, run: () => pick(f) });
  }
  if (!files.length) items.push({ label: 'No .ditaval files in project', disabled: true });
  return items;
}

function recentMenuItems() {
  let list = [];
  try { list = JSON.parse(localStorage.getItem('ds:recentRoots') || '[]'); } catch (e) { /* ignore */ }
  if (!list.length) return [{ label: 'No recent projects', disabled: true }];
  return list.map(r => ({ label: r, run: () => openProjectPath(r) }));
}

const MENUBAR = [
  {
    name: 'File',
    items: () => [
      { label: 'New file…', hint: 'Ctrl+N', disabled: $('btnNewFile').disabled, run: () => { S.pendingInsert = null; openNewFileDialog(); } },
      { label: 'Open folder…', run: () => $('btnOpenFolder').click() },
      { label: 'Recent projects', sub: recentMenuItems() },
      '-',
      { label: 'Save', hint: 'Ctrl+S', disabled: !S.file, run: save },
      { label: 'Close tab', hint: 'Ctrl+W', disabled: TABS.active < 0, run: () => closeTab(TABS.active) },
      '-',
      { label: 'Autosaved versions…', disabled: !S.file, run: () => $('btnVersions').click() },
      { label: 'Reveal in File Explorer', disabled: !S.file, run: () => window.api.showInFolder(S.file) }
    ]
  },
  {
    name: 'Edit',
    items: () => [
      { label: 'Find in file…', hint: 'Ctrl+F', disabled: !S.file, run: () => { monacoEd.focus(); monacoEd.getAction('actions.find').run(); } },
      { label: 'Replace in file…', hint: 'Ctrl+H', disabled: !S.file, run: () => { monacoEd.focus(); monacoEd.getAction('editor.action.startFindReplaceAction').run(); } },
      { label: 'Find in files…', hint: 'Ctrl+Shift+F', run: () => setRightMode('search') },
      '-',
      { label: 'Insert link to file…', hint: 'Ctrl+K', disabled: !S.file, run: () => openQuickOpen('link') },
      { label: 'Insert table…', disabled: !canInsertMarkup(), run: openTableDialog },
      { label: 'Insert image…', disabled: !canInsertMarkup(), run: insertImageFile },
      { label: 'Insert video / audio file…', disabled: !canInsertMarkup(), run: insertLocalMedia },
      { label: 'Embed online video / audio…', disabled: !canInsertMarkup(), run: () => { $('embedUrl').value = ''; $('dlgEmbed').showModal(); } }
    ]
  },
  {
    name: 'View',
    items: () => [
      { label: 'Preview', run: () => setRightMode('preview') },
      { label: 'Map browser', run: () => setRightMode('map') },
      { label: 'Dependencies', run: () => setRightMode('deps') },
      { label: 'Problems', run: () => setRightMode('problems') },
      { label: 'Outline', run: () => setRightMode('outline') },
      { label: 'Find in files', run: () => setRightMode('search') },
      { label: 'AI assistant', run: () => setRightMode('assist') },
      '-',
      { label: 'Toggle sidebar', hint: 'Ctrl+B', run: toggleSidebar },
      { label: 'Toggle preview theme', run: () => $('btnPreviewTheme').click() }
    ]
  },
  {
    name: 'Publish',
    items: () => [
      { label: 'Export HTML…', disabled: !S.file, run: () => $('btnExportHTML').click() },
      { label: 'Export PDF…', disabled: !S.file, run: () => $('btnExportPDF').click() },
      { label: 'Generate documentation site…', disabled: !S.file, run: () => openSiteDialog() },
      { label: 'DITA-OT build…', disabled: !S.file, run: () => $('btnPublishOT').click() },
      '-',
      { label: 'DITAVAL filter', sub: ditavalMenuItems() },
      { label: 'Set open map as root map', disabled: !(S.file && isMap(S.file)), run: () => $('btnRootMap').click() }
    ]
  },
  {
    name: 'Tools',
    items: () => [
      { label: 'Command palette…', hint: 'Ctrl+Shift+P', run: () => openQuickOpen('commands') },
      { label: 'Quick open…', hint: 'Ctrl+P', run: () => openQuickOpen('files') },
      { label: 'Rebuild dependency index', disabled: !S.root, run: async () => { await buildDepIndex(); renderDeps(); } },
      { label: 'AI Assistant', run: () => setRightMode('ai') },
      '-',
      { label: 'Settings…', run: () => $('btnSettings').click() }
    ]
  },
  {
    name: 'Help',
    items: () => [
      { label: 'How to use DITA Studio', run: () => openDocDialog(window.DOCS.GUIDE) },
      { label: "What's new (changelog)", run: () => openDocDialog(window.DOCS.CHANGELOG) },
      { label: 'Keyboard shortcuts', run: () => $('dlgHelp').showModal() },
      '-',
      { label: 'About DITA Studio', run: () => toast(`DITA Studio ${APP_VERSION} — DITA · LwDITA · Markdown · MDX workbench`) }
    ]
  }
];

function openMenu(btn, def) {
  document.querySelectorAll('.mb-item.open').forEach(b => b.classList.remove('open'));
  btn.classList.add('open');
  menubarOpen = def.name;
  const r = btn.getBoundingClientRect();
  renderMenuItems(def.items(), r.left, r.bottom + 4, null);
}

(function buildMenubar() {
  const host = $('menubar');
  for (const def of MENUBAR) {
    const b = document.createElement('button');
    b.className = 'mb-item';
    b.textContent = def.name;
    b.onclick = e => {
      e.stopPropagation();
      if (menubarOpen === def.name) { hideContextMenu(); return; }
      openMenu(b, def);
    };
    b.onmouseenter = () => { if (menubarOpen && menubarOpen !== def.name) openMenu(b, def); };
    host.appendChild(b);
  }
})();

$('btnSaveQuick').onclick = save;
$('btnHelpClose').onclick = () => $('dlgHelp').close();
$('stDitaval').onclick = () => {
  const btn = Array.from(document.querySelectorAll('.mb-item')).find(b => b.textContent === 'Publish');
  if (btn) openMenu(btn, MENUBAR.find(m => m.name === 'Publish'));
};

/* ================================================================
   v1.9: table builder + media insertion
   ================================================================ */

function canInsertMarkup() {
  return !!(S.file && (isDita(S.file) || isMd(S.file) || isMdx(S.file)) && !isMap(S.file));
}

/* ---------------- visual table builder ---------------- */

function mdTableSrc(rows, cols, header) {
  const cell = '        ';
  const line = n => '|' + Array(n).fill(` ${'Cell'.padEnd(6)} `).join('|') + '|';
  const out = [];
  if (header) {
    out.push('|' + Array(cols).fill(' Header ').join('|') + '|');
    out.push('|' + Array(cols).fill(' ------ ').join('|') + '|');
  }
  const bodyRows = header ? rows - 1 : rows;
  for (let r = 0; r < Math.max(1, bodyRows); r++) out.push(line(cols));
  return '\n' + out.join('\n') + '\n';
}

function ditaSimpletableSrc(rows, cols, header) {
  const ent = tag => `    <${tag}></${tag}>`;
  const out = ['<simpletable>'];
  if (header) {
    out.push('  <sthead>');
    for (let c = 0; c < cols; c++) out.push(ent('stentry'));
    out.push('  </sthead>');
  }
  const bodyRows = header ? rows - 1 : rows;
  for (let r = 0; r < Math.max(1, bodyRows); r++) {
    out.push('  <strow>');
    for (let c = 0; c < cols; c++) out.push(ent('stentry'));
    out.push('  </strow>');
  }
  out.push('</simpletable>');
  return out.join('\n');
}

function ditaCalsSrc(rows, cols, header) {
  const out = [`<table>`, `  <tgroup cols="${cols}">`];
  for (let c = 1; c <= cols; c++) out.push(`    <colspec colname="c${c}" colwidth="1*"/>`);
  const row = () => {
    const r = ['      <row>'];
    for (let c = 0; c < cols; c++) r.push('        <entry></entry>');
    r.push('      </row>');
    return r;
  };
  if (header) {
    out.push('    <thead>');
    out.push(...row());
    out.push('    </thead>');
  }
  out.push('    <tbody>');
  const bodyRows = header ? rows - 1 : rows;
  for (let r = 0; r < Math.max(1, bodyRows); r++) out.push(...row());
  out.push('    </tbody>', '  </tgroup>', '</table>');
  return out.join('\n');
}

function openTableDialog() {
  if (!canInsertMarkup()) { toast('Open a DITA or Markdown file first.'); return; }
  $('tblFmtWrap').style.display = isDita(S.file) ? '' : 'none';
  buildTableGrid();
  syncTableGrid();
  $('dlgTable').showModal();
}

function buildTableGrid() {
  const host = $('tblGrid');
  if (host.childElementCount) return;
  for (let r = 1; r <= 8; r++) {
    for (let c = 1; c <= 8; c++) {
      const d = document.createElement('div');
      d.className = 'tbl-cell';
      d.dataset.r = r;
      d.dataset.c = c;
      d.onmouseenter = () => {
        $('tblRows').value = r;
        $('tblCols').value = c;
        syncTableGrid();
      };
      d.onclick = () => $('btnTblInsert').click();
      host.appendChild(d);
    }
  }
}

function syncTableGrid() {
  const r = +$('tblRows').value || 1;
  const c = +$('tblCols').value || 1;
  $('tblDims').textContent = `${r} × ${c}` + ($('tblHeader').checked ? ' (first row = header)' : '');
  document.querySelectorAll('.tbl-cell').forEach(cell => {
    cell.classList.toggle('on', +cell.dataset.r <= Math.min(r, 8) && +cell.dataset.c <= Math.min(c, 8));
  });
}
['tblRows', 'tblCols', 'tblHeader'].forEach(id => $(id).addEventListener('input', syncTableGrid));

$('btnTblCancel').onclick = () => $('dlgTable').close();
$('btnTblInsert').onclick = () => {
  const rows = Math.max(1, +$('tblRows').value || 1);
  const cols = Math.max(1, +$('tblCols').value || 1);
  const header = $('tblHeader').checked;
  let src;
  if (isDita(S.file)) {
    src = $('tblFmt').value === 'cals' ? ditaCalsSrc(rows, cols, header) : ditaSimpletableSrc(rows, cols, header);
  } else {
    src = mdTableSrc(rows, cols, header);
  }
  $('dlgTable').close();
  insertAtCaret(src);
  toast(`Inserted a ${rows} × ${cols} table.`);
};

/* ---------------- media insertion ---------------- */

async function insertImageFile() {
  if (!canInsertMarkup()) return;
  const f = await window.api.pickFile('Choose an image', [{ name: 'Images', extensions: ['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg'] }]);
  if (!f) return;
  const rel = P.relative(P.dirname(S.file), f).split(P.sep).join('/');
  const name = P.basename(f, extOf(f));
  if (isDita(S.file)) insertAtCaret(`<image href="${rel}"><alt>${name}</alt></image>`);
  else insertAtCaret(`![${name}](${rel})`);
}

async function insertLocalMedia() {
  if (!canInsertMarkup()) return;
  const f = await window.api.pickFile('Choose a video or audio file', [
    { name: 'Media', extensions: ['mp4', 'webm', 'ogv', 'mov', 'm4v', 'mp3', 'wav', 'm4a', 'ogg', 'flac', 'aac'] }
  ]);
  if (!f) return;
  const rel = P.relative(P.dirname(S.file), f).split(P.sep).join('/');
  const isVideo = window.DITA_MEDIA.VIDEO_EXT.test(rel);
  if (isDita(S.file)) {
    insertAtCaret(`<object data="${rel}"/>`);
  } else {
    insertAtCaret(isVideo
      ? `\n<video controls preload="metadata" src="${rel}"></video>\n`
      : `\n<audio controls preload="metadata" src="${rel}"></audio>\n`);
  }
  toast('Media inserted — it plays in the preview and in HTML / Doc Site output.');
}

$('btnEmbedCancel').onclick = () => $('dlgEmbed').close();
$('btnEmbedInsert').onclick = () => {
  const url = $('embedUrl').value.trim();
  if (!url) return;
  $('dlgEmbed').close();
  if (!canInsertMarkup()) return;
  if (isDita(S.file)) {
    insertAtCaret(`<object data="${url}" outputclass="embed"/>`);
  } else if (window.DITA_MEDIA.AUDIO_EXT.test(url)) {
    insertAtCaret(`\n<audio controls src="${url}"></audio>\n`);
  } else {
    const embed = window.DITA_MEDIA.embedUrl(url);
    insertAtCaret(`\n<div class="d-embed"><iframe src="${embed}" loading="lazy" allowfullscreen allow="autoplay; encrypted-media; picture-in-picture"></iframe></div>\n`);
  }
  toast('Embed inserted.');
};

/* ================================================================
   v2.0: in-app docs viewer + AI writing assistant
   ================================================================ */

/* ---------------- Help: user guide & changelog ---------------- */

async function openDocViewer(kind) {
  const md = await window.api.readDoc(kind);
  $('docTitle').textContent = kind === 'changelog' ? "What's new" : 'User guide';
  const body = window.api.renderMarkdown(md);
  $('docFrame').srcdoc = `<!DOCTYPE html><html><head><meta charset="utf-8"><style>${publishCss('light')}
    body{padding:20px 26px;font-size:14px} h1{font-size:1.45em} h2{font-size:1.2em} table{border-collapse:collapse} td,th{border:1px solid #e1e5ea;padding:5px 9px}</style></head><body>${body}</body></html>`;
  $('dlgDoc').showModal();
}
$('btnDocClose').onclick = () => $('dlgDoc').close();

/* ---------------- AI writing assistant ---------------- */

const AI_PROVIDERS = {
  ollama: {
    label: 'Ollama — local, free', style: 'openai',
    baseUrl: 'http://localhost:11434/v1', model: 'llama3.1', keyNeeded: false,
    site: 'https://ollama.com',
    hint: 'Free and private: install Ollama, run `ollama pull llama3.1` (or qwen2.5, deepseek-r1…), keep it running. No account, no key, nothing leaves your machine.'
  },
  lmstudio: {
    label: 'LM Studio — local, free', style: 'openai',
    baseUrl: 'http://localhost:1234/v1', model: 'local-model', keyNeeded: false,
    site: 'https://lmstudio.ai',
    hint: 'Free and private: load any model in LM Studio and start its local server (Developer tab). No account needed.'
  },
  anthropic: {
    label: 'Anthropic Claude — API key', style: 'anthropic',
    baseUrl: 'https://api.anthropic.com', model: 'claude-sonnet-4-5', keyNeeded: true,
    site: 'https://console.anthropic.com/settings/keys',
    hint: 'Paid API. Create a key in the Anthropic Console (log in → API keys). Strong at long technical documents.'
  },
  openai: {
    label: 'OpenAI — API key', style: 'openai',
    baseUrl: 'https://api.openai.com/v1', model: 'gpt-4o-mini', keyNeeded: true,
    site: 'https://platform.openai.com/api-keys',
    hint: 'Paid API. Create a key at platform.openai.com after logging in.'
  },
  deepseek: {
    label: 'DeepSeek — API key', style: 'openai',
    baseUrl: 'https://api.deepseek.com/v1', model: 'deepseek-chat', keyNeeded: true,
    site: 'https://platform.deepseek.com',
    hint: 'Low-cost API, strong Chinese/English. Log in at platform.deepseek.com to create a key.'
  },
  moonshot: {
    label: 'Moonshot Kimi — API key', style: 'openai',
    baseUrl: 'https://api.moonshot.cn/v1', model: 'moonshot-v1-8k', keyNeeded: true,
    site: 'https://platform.moonshot.cn',
    hint: 'Kimi API (CN). Log in at platform.moonshot.cn to create a key. Adjust the model name to the one your account offers.'
  },
  openrouter: {
    label: 'OpenRouter — many models, has :free tier', style: 'openai',
    baseUrl: 'https://openrouter.ai/api/v1', model: 'deepseek/deepseek-chat-v3.1:free', keyNeeded: true,
    site: 'https://openrouter.ai/keys',
    hint: 'One key, hundreds of models — including zero-cost ones with a ":free" suffix (account required, no payment). Log in at openrouter.ai to create a key.'
  }
};

const AI_ACTIONS = {
  improve: 'Improve the clarity, flow, and concision of the following text. Keep its meaning, terminology, and markup format exactly.',
  grammar: 'Fix grammar, spelling, and punctuation in the following text. Change nothing else. Keep the markup format exactly.',
  en: 'Translate the following text into natural, professional English. Keep all markup (XML tags / Markdown syntax) exactly as-is; translate only human-readable text.',
  zh: 'Translate the following text into natural, professional Simplified Chinese. Keep all markup (XML tags / Markdown syntax) exactly as-is; translate only human-readable text.',
  summarize: 'Write a one-to-two sentence summary of the following content, suitable for a DITA shortdesc or an abstract. Return only the summary.',
  continue: 'Continue writing from where the following text ends, matching its style, terminology, and markup format. Return only the continuation.'
};

const AI_SYSTEM = 'You are a technical-writing assistant embedded in a DITA/Markdown documentation editor. Always return ONLY the resulting text with no explanations, no preamble, and no code fences that were not in the input. Preserve the input\'s markup format (XML tags or Markdown) exactly.';

function aiSettings() {
  if (!SETTINGS.ai) SETTINGS.ai = { provider: 'ollama', models: {}, keys: {} };
  return SETTINGS.ai;
}

let aiPaneReady = false;
let aiLastOutput = null;

function initAiPane() {
  const a = aiSettings();
  if (!aiPaneReady) {
    aiPaneReady = true;
    const sel = $('aiProvider');
    for (const [k, p] of Object.entries(AI_PROVIDERS)) {
      const o = document.createElement('option');
      o.value = k;
      o.textContent = p.label;
      sel.appendChild(o);
    }
    sel.onchange = () => { a.provider = sel.value; saveSettings(); refreshAiFields(); };
    $('aiModel').onchange = () => { a.models[a.provider] = $('aiModel').value.trim(); saveSettings(); };
    $('aiKey').onchange = () => { a.keys[a.provider] = $('aiKey').value.trim(); saveSettings(); };
    $('btnAiKeyLink').onclick = () => window.api.openExternal(AI_PROVIDERS[a.provider].site);
    document.querySelectorAll('.ai-act').forEach(b => b.onclick = () => runAi(AI_ACTIONS[b.dataset.act]));
    $('aiCustom').addEventListener('keydown', e => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); runAi($('aiCustom').value.trim()); }
    });
    $('btnAiInsert').onclick = () => { if (aiLastOutput != null) { insertAtCaret(aiLastOutput); toast('Inserted.'); } };
    $('btnAiReplace').onclick = () => {
      if (aiLastOutput == null) return;
      const sel2 = monacoEd.getSelection();
      if (sel2 && !sel2.isEmpty()) {
        monacoEd.executeEdits('ai', [{ range: sel2, text: aiLastOutput, forceMoveMarkers: true }]);
        toast('Selection replaced.');
      } else { insertAtCaret(aiLastOutput); toast('No selection — inserted at cursor.'); }
    };
    $('btnAiCopy').onclick = () => { navigator.clipboard.writeText(aiLastOutput || ''); toast('Copied.'); };
  }
  $('aiProvider').value = a.provider;
  refreshAiFields();
}

function refreshAiFields() {
  const a = aiSettings();
  const p = AI_PROVIDERS[a.provider];
  $('aiModel').value = a.models[a.provider] || p.model;
  $('aiKey').value = a.keys[a.provider] || '';
  $('aiKey').placeholder = p.keyNeeded ? 'API key (stored locally, unencrypted)' : 'No key needed — local model';
  $('aiKey').disabled = false;
  $('aiHint').textContent = p.hint;
}

function aiSourceText() {
  const sel = monacoEd.getSelection();
  const m = activeModel();
  if (!m) return { text: '', scope: 'nothing' };
  if (sel && !sel.isEmpty()) return { text: m.getValueInRange(sel), scope: 'selection' };
  return { text: m.getValue().slice(0, 24000), scope: 'document' };
}

async function runAi(instruction) {
  if (!instruction) { toast('Type an instruction first.'); return; }
  if (!S.file) { toast('Open a file first.'); return; }
  const a = aiSettings();
  const p = AI_PROVIDERS[a.provider];
  const key = a.keys[a.provider] || '';
  if (p.keyNeeded && !key) {
    $('aiStatus').textContent = 'This provider needs an API key — paste one above (Get key opens the provider console).';
    return;
  }
  const { text, scope } = aiSourceText();
  if (!text.trim()) { toast('The document is empty.'); return; }
  $('aiStatus').textContent = `Asking ${p.label.split(' — ')[0]} (${scope}, ${text.length} chars)…`;
  $('aiOut').hidden = true;
  $('aiOutActions').hidden = true;
  document.querySelectorAll('.ai-act, #btnAiRun').forEach(b => b.disabled = true);
  const r = await window.api.aiChat({
    style: p.style,
    baseUrl: p.baseUrl,
    apiKey: key,
    model: $('aiModel').value.trim() || p.model,
    system: AI_SYSTEM,
    user: instruction + '\n\n----- TEXT -----\n' + text,
    maxTokens: 4096
  });
  document.querySelectorAll('.ai-act').forEach(b => b.disabled = false);
  if (r.error) {
    $('aiStatus').textContent = 'Error: ' + r.error;
    return;
  }
  aiLastOutput = (r.text || '').trim();
  $('aiStatus').textContent = `Done (${aiLastOutput.length} chars). Review below, then insert or replace.`;
  $('aiOut').textContent = aiLastOutput;
  $('aiOut').hidden = false;
  $('aiOutActions').hidden = false;
}
